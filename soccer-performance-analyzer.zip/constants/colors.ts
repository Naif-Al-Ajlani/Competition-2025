export default {
  light: {
    text: "#1A1A1A",
    background: "#FFFFFF",
    primary: "#4361EE",
    secondary: "#3A0CA3",
    accent: "#F72585",
    card: "#F5F5F7",
    border: "#E1E1E8",
    success: "#2EC4B6",
    error: "#E63946",
    inactive: "#9CA3AF",
  },
  dark: {
    text: "#F5F5F7",
    background: "#121212",
    primary: "#4361EE",
    secondary: "#7209B7",
    accent: "#F72585",
    card: "#1E1E1E",
    border: "#2A2A2A",
    success: "#2EC4B6",
    error: "#E63946",
    inactive: "#6B7280",
  }
};
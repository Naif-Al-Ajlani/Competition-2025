import React, { useState, useRef } from 'react';
import { View, Text, StyleSheet, Pressable, Dimensions } from 'react-native';
import { Image } from 'expo-image';
import { Play, Pause, SkipBack, SkipForward, Layers, Layers3 } from 'lucide-react-native';
import colors from '@/constants/colors';
import { VideoSource } from '@/types/comparison';
import { PoseData } from '@/types/analysis';
import PoseOverlay from './PoseOverlay';

interface EnhancedVideoPlayerProps {
  video: VideoSource;
  poseData?: PoseData;
  style?: object;
  overlayColor?: string;
  showPoseOverlay?: boolean;
}

const EnhancedVideoPlayer: React.FC<EnhancedVideoPlayerProps> = ({ 
  video, 
  poseData, 
  style,
  overlayColor = colors.dark.primary,
  showPoseOverlay = false
}) => {
  const [isPlaying, setIsPlaying] = useState(false);
  const [progress, setProgress] = useState(0);
  const [isPoseVisible, setIsPoseVisible] = useState(showPoseOverlay);
  const intervalRef = useRef<NodeJS.Timeout | null>(null);
  
  // Get dimensions for the video container
  const [dimensions, setDimensions] = useState({
    width: 0,
    height: 0
  });
  
  const onLayout = (event: any) => {
    const { width, height } = event.nativeEvent.layout;
    setDimensions({ width, height });
  };
  
  // In a real app, we would use expo-av to play videos
  // For this demo, we'll just show the thumbnail and simulate playback
  const togglePlayback = () => {
    if (isPlaying) {
      if (intervalRef.current) {
        clearInterval(intervalRef.current);
        intervalRef.current = null;
      }
      setIsPlaying(false);
    } else {
      setIsPlaying(true);
      
      // Simulate progress for demo purposes
      intervalRef.current = setInterval(() => {
        setProgress(prev => {
          if (prev >= 1) {
            if (intervalRef.current) {
              clearInterval(intervalRef.current);
              intervalRef.current = null;
            }
            setIsPlaying(false);
            return 0;
          }
          return prev + 0.01;
        });
      }, 100);
    }
  };
  
  const resetPlayback = () => {
    if (intervalRef.current) {
      clearInterval(intervalRef.current);
      intervalRef.current = null;
    }
    setProgress(0);
    setIsPlaying(false);
  };
  
  const togglePoseOverlay = () => {
    setIsPoseVisible(!isPoseVisible);
  };
  
  return (
    <View style={[styles.container, style]}>
      <View style={styles.videoContainer} onLayout={onLayout}>
        <Image
          source={{ uri: video.thumbnail }}
          style={styles.thumbnail}
          contentFit="cover"
        />
        
        {/* Pose overlay */}
        {isPoseVisible && poseData && dimensions.width > 0 && dimensions.height > 0 && (
          <PoseOverlay 
            poseData={poseData} 
            color={overlayColor}
            width={dimensions.width}
            height={dimensions.height}
          />
        )}
        
        {/* Progress bar */}
        <View style={styles.progressContainer}>
          <View 
            style={[
              styles.progressBar, 
              { width: `${progress * 100}%`, backgroundColor: overlayColor }
            ]} 
          />
        </View>
        
        {/* Play button overlay */}
        {!isPlaying && (
          <Pressable 
            style={styles.playOverlay}
            onPress={togglePlayback}
          >
            <View style={styles.playButton}>
              <Play size={24} color={colors.dark.text} />
            </View>
          </Pressable>
        )}
      </View>
      
      {/* Controls */}
      <View style={styles.controls}>
        <Pressable onPress={resetPlayback}>
          <SkipBack size={24} color={colors.dark.text} />
        </Pressable>
        
        <Pressable onPress={togglePlayback}>
          {isPlaying ? (
            <Pause size={32} color={colors.dark.text} />
          ) : (
            <Play size={32} color={colors.dark.text} />
          )}
        </Pressable>
        
        <Pressable>
          <SkipForward size={24} color={colors.dark.text} />
        </Pressable>
        
        {poseData && (
          <Pressable onPress={togglePoseOverlay} style={styles.poseToggle}>
            {isPoseVisible ? (
              <Layers3 size={24} color={overlayColor} />
            ) : (
              <Layers size={24} color={colors.dark.inactive} />
            )}
            <Text style={[styles.poseToggleText, isPoseVisible ? {color: overlayColor} : {color: colors.dark.inactive}]}>
              {isPoseVisible ? "Hide Pose" : "Show Pose"}
            </Text>
          </Pressable>
        )}
      </View>
      
      <Text style={styles.title}>{video.title}</Text>
      {video.duration && (
        <Text style={styles.duration}>{video.duration}s</Text>
      )}
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    borderRadius: 12,
    overflow: 'hidden',
    backgroundColor: colors.dark.card,
  },
  videoContainer: {
    position: 'relative',
    aspectRatio: 16/9,
    borderRadius: 8,
    overflow: 'hidden',
  },
  thumbnail: {
    width: '100%',
    height: '100%',
  },
  playOverlay: {
    ...StyleSheet.absoluteFillObject,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: 'rgba(0,0,0,0.3)',
  },
  playButton: {
    width: 50,
    height: 50,
    borderRadius: 25,
    backgroundColor: 'rgba(255,255,255,0.8)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  progressContainer: {
    position: 'absolute',
    bottom: 0,
    left: 0,
    right: 0,
    height: 4,
    backgroundColor: 'rgba(255,255,255,0.2)',
  },
  progressBar: {
    height: '100%',
  },
  controls: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    alignItems: 'center',
    paddingVertical: 12,
  },
  poseToggle: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
  },
  poseToggleText: {
    fontSize: 12,
    fontWeight: '500',
  },
  title: {
    fontSize: 16,
    fontWeight: '600',
    color: colors.dark.text,
    paddingHorizontal: 12,
    paddingBottom: 4,
  },
  duration: {
    fontSize: 14,
    color: colors.dark.inactive,
    paddingHorizontal: 12,
    paddingBottom: 12,
  }
});

export default EnhancedVideoPlayer;
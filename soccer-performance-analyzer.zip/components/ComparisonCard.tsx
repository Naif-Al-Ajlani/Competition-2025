import React from 'react';
import { View, Text, StyleSheet, Pressable } from 'react-native';
import { Image } from 'expo-image';
import { useRouter } from 'expo-router';
import { Calendar, Tag } from 'lucide-react-native';
import colors from '@/constants/colors';
import { Comparison } from '@/types/comparison';

interface ComparisonCardProps {
  comparison: Comparison;
}

export default function ComparisonCard({ comparison }: ComparisonCardProps) {
  const router = useRouter();
  
  const handlePress = () => {
    router.push(`/comparison/${comparison.id}`);
  };
  
  // Get thumbnails from videos if available
  const referenceThumbnail = comparison.videos.reference?.thumbnail;
  const trainingThumbnail = comparison.videos.training?.thumbnail;
  
  // Format date
  const formattedDate = new Date(comparison.updatedAt).toLocaleDateString();
  
  return (
    <Pressable 
      style={styles.container}
      onPress={handlePress}
    >
      <View style={styles.thumbnailContainer}>
        {referenceThumbnail && (
          <Image
            source={{ uri: referenceThumbnail }}
            style={styles.thumbnail}
            contentFit="cover"
          />
        )}
        {trainingThumbnail && (
          <Image
            source={{ uri: trainingThumbnail }}
            style={styles.thumbnail}
            contentFit="cover"
          />
        )}
        {!referenceThumbnail && !trainingThumbnail && (
          <View style={styles.placeholderThumbnail}>
            <Text style={styles.placeholderText}>No videos yet</Text>
          </View>
        )}
      </View>
      
      <View style={styles.content}>
        <Text style={styles.title} numberOfLines={1}>{comparison.title}</Text>
        
        {comparison.description && (
          <Text style={styles.description} numberOfLines={2}>
            {comparison.description}
          </Text>
        )}
        
        <View style={styles.metaContainer}>
          <View style={styles.metaItem}>
            <Calendar size={14} color={colors.dark.inactive} />
            <Text style={styles.metaText}>{formattedDate}</Text>
          </View>
          
          {comparison.tags && comparison.tags.length > 0 && (
            <View style={styles.metaItem}>
              <Tag size={14} color={colors.dark.inactive} />
              <Text style={styles.metaText} numberOfLines={1}>
                {comparison.tags.join(', ')}
              </Text>
            </View>
          )}
        </View>
      </View>
    </Pressable>
  );
}

const styles = StyleSheet.create({
  container: {
    flexDirection: 'row',
    backgroundColor: colors.dark.card,
    borderRadius: 12,
    marginBottom: 16,
    overflow: 'hidden',
  },
  thumbnailContainer: {
    width: 120,
    height: 120,
    flexDirection: 'column',
  },
  thumbnail: {
    flex: 1,
    width: '100%',
  },
  placeholderThumbnail: {
    flex: 1,
    backgroundColor: colors.dark.border,
    justifyContent: 'center',
    alignItems: 'center',
  },
  placeholderText: {
    color: colors.dark.inactive,
    fontSize: 12,
  },
  content: {
    flex: 1,
    padding: 12,
    justifyContent: 'space-between',
  },
  title: {
    fontSize: 16,
    fontWeight: '600',
    color: colors.dark.text,
    marginBottom: 4,
  },
  description: {
    fontSize: 14,
    color: colors.dark.inactive,
    marginBottom: 8,
    flex: 1,
  },
  metaContainer: {
    flexDirection: 'column',
    gap: 4,
  },
  metaItem: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
  },
  metaText: {
    fontSize: 12,
    color: colors.dark.inactive,
  }
});
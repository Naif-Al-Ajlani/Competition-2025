import React from 'react';
import { View, Text, StyleSheet, Pressable, Modal } from 'react-native';
import { X, Info } from 'lucide-react-native';
import colors from '@/constants/colors';

interface VideoTutorialProps {
  visible: boolean;
  onClose: () => void;
}

const VideoTutorial: React.FC<VideoTutorialProps> = ({ visible, onClose }) => {
  return (
    <Modal
      animationType="fade"
      transparent={true}
      visible={visible}
      onRequestClose={onClose}
    >
      <View style={styles.modalOverlay}>
        <View style={styles.modalContent}>
          <View style={styles.header}>
            <Text style={styles.title}>How to Use Pose Analysis</Text>
            <Pressable onPress={onClose} style={styles.closeButton}>
              <X size={24} color={colors.dark.text} />
            </Pressable>
          </View>
          
          <View style={styles.tutorialContent}>
            <View style={styles.tutorialItem}>
              <View style={styles.stepCircle}>
                <Text style={styles.stepNumber}>1</Text>
              </View>
              <View style={styles.stepContent}>
                <Text style={styles.stepTitle}>Upload Videos</Text>
                <Text style={styles.stepDescription}>
                  Upload a reference video (professional technique) and your training video for comparison.
                </Text>
              </View>
            </View>
            
            <View style={styles.tutorialItem}>
              <View style={styles.stepCircle}>
                <Text style={styles.stepNumber}>2</Text>
              </View>
              <View style={styles.stepContent}>
                <Text style={styles.stepTitle}>Run Analysis</Text>
                <Text style={styles.stepDescription}>
                  Click "Analyze Technique" to have our AI analyze your form compared to the reference.
                </Text>
              </View>
            </View>
            
            <View style={styles.tutorialItem}>
              <View style={styles.stepCircle}>
                <Text style={styles.stepNumber}>3</Text>
              </View>
              <View style={styles.stepContent}>
                <Text style={styles.stepTitle}>View Skeleton Overlay</Text>
                <Text style={styles.stepDescription}>
                  Toggle the skeleton overlay using the layers icon in the video controls to see body positioning.
                </Text>
              </View>
            </View>
            
            <View style={styles.tutorialItem}>
              <View style={styles.stepCircle}>
                <Text style={styles.stepNumber}>4</Text>
              </View>
              <View style={styles.stepContent}>
                <Text style={styles.stepTitle}>Review Metrics</Text>
                <Text style={styles.stepDescription}>
                  Check the detailed metrics for angles, timing, and positioning to identify areas for improvement.
                </Text>
              </View>
            </View>
            
            <View style={styles.infoContainer}>
              <Info size={20} color={colors.dark.primary} />
              <Text style={styles.infoText}>
                The skeleton overlay helps you visualize body positioning differences between your technique and the reference.
              </Text>
            </View>
          </View>
          
          <Pressable style={styles.gotItButton} onPress={onClose}>
            <Text style={styles.gotItButtonText}>Got It</Text>
          </Pressable>
        </View>
      </View>
    </Modal>
  );
};

const styles = StyleSheet.create({
  modalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0, 0, 0, 0.7)',
    justifyContent: 'center',
    alignItems: 'center',
    padding: 20,
  },
  modalContent: {
    backgroundColor: colors.dark.card,
    borderRadius: 16,
    width: '100%',
    maxWidth: 500,
    padding: 20,
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 20,
  },
  title: {
    fontSize: 20,
    fontWeight: 'bold',
    color: colors.dark.text,
  },
  closeButton: {
    padding: 4,
  },
  tutorialContent: {
    gap: 20,
  },
  tutorialItem: {
    flexDirection: 'row',
    gap: 16,
    alignItems: 'flex-start',
  },
  stepCircle: {
    width: 32,
    height: 32,
    borderRadius: 16,
    backgroundColor: colors.dark.primary,
    justifyContent: 'center',
    alignItems: 'center',
  },
  stepNumber: {
    fontSize: 16,
    fontWeight: 'bold',
    color: colors.dark.text,
  },
  stepContent: {
    flex: 1,
  },
  stepTitle: {
    fontSize: 16,
    fontWeight: '600',
    color: colors.dark.text,
    marginBottom: 4,
  },
  stepDescription: {
    fontSize: 14,
    color: colors.dark.inactive,
    lineHeight: 20,
  },
  infoContainer: {
    flexDirection: 'row',
    backgroundColor: 'rgba(67, 97, 238, 0.1)',
    borderRadius: 8,
    padding: 12,
    gap: 12,
    alignItems: 'flex-start',
    marginTop: 8,
  },
  infoText: {
    flex: 1,
    fontSize: 14,
    color: colors.dark.text,
    lineHeight: 20,
  },
  gotItButton: {
    backgroundColor: colors.dark.primary,
    borderRadius: 8,
    padding: 14,
    alignItems: 'center',
    marginTop: 24,
  },
  gotItButtonText: {
    fontSize: 16,
    fontWeight: '600',
    color: colors.dark.text,
  },
});

export default VideoTutorial;
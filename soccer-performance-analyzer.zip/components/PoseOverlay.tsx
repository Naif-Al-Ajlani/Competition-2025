import React from 'react';
import { View, StyleSheet } from 'react-native';
import { PoseData } from '@/types/analysis';
import colors from '@/constants/colors';

interface PoseOverlayProps {
  poseData: PoseData;
  color?: string;
  width: number;
  height: number;
}

const PoseOverlay: React.FC<PoseOverlayProps> = ({ 
  poseData, 
  color = colors.dark.primary, 
  width, 
  height 
}) => {
  const { joints } = poseData;
  
  // Draw lines between joints to form a skeleton
  const renderBones = () => {
    return (
      <>
        {/* Neck to head */}
        <View style={[
          styles.bone,
          {
            left: joints.neck.x * width,
            top: joints.neck.y * height,
            width: getDistance(joints.neck, joints.head) * width,
            height: 2,
            transform: [{ 
              rotate: `${getAngle(joints.neck, joints.head)}rad` 
            }],
            backgroundColor: color,
            opacity: (joints.neck.confidence + joints.head.confidence) / 2
          }
        ]} />
        
        {/* Neck to right shoulder */}
        <View style={[
          styles.bone,
          {
            left: joints.neck.x * width,
            top: joints.neck.y * height,
            width: getDistance(joints.neck, joints.rightShoulder) * width,
            height: 2,
            transform: [{ 
              rotate: `${getAngle(joints.neck, joints.rightShoulder)}rad` 
            }],
            backgroundColor: color,
            opacity: (joints.neck.confidence + joints.rightShoulder.confidence) / 2
          }
        ]} />
        
        {/* Neck to left shoulder */}
        <View style={[
          styles.bone,
          {
            left: joints.neck.x * width,
            top: joints.neck.y * height,
            width: getDistance(joints.neck, joints.leftShoulder) * width,
            height: 2,
            transform: [{ 
              rotate: `${getAngle(joints.neck, joints.leftShoulder)}rad` 
            }],
            backgroundColor: color,
            opacity: (joints.neck.confidence + joints.leftShoulder.confidence) / 2
          }
        ]} />
        
        {/* Right shoulder to right elbow */}
        <View style={[
          styles.bone,
          {
            left: joints.rightShoulder.x * width,
            top: joints.rightShoulder.y * height,
            width: getDistance(joints.rightShoulder, joints.rightElbow) * width,
            height: 2,
            transform: [{ 
              rotate: `${getAngle(joints.rightShoulder, joints.rightElbow)}rad` 
            }],
            backgroundColor: color,
            opacity: (joints.rightShoulder.confidence + joints.rightElbow.confidence) / 2
          }
        ]} />
        
        {/* Right elbow to right wrist */}
        <View style={[
          styles.bone,
          {
            left: joints.rightElbow.x * width,
            top: joints.rightElbow.y * height,
            width: getDistance(joints.rightElbow, joints.rightWrist) * width,
            height: 2,
            transform: [{ 
              rotate: `${getAngle(joints.rightElbow, joints.rightWrist)}rad` 
            }],
            backgroundColor: color,
            opacity: (joints.rightElbow.confidence + joints.rightWrist.confidence) / 2
          }
        ]} />
        
        {/* Left shoulder to left elbow */}
        <View style={[
          styles.bone,
          {
            left: joints.leftShoulder.x * width,
            top: joints.leftShoulder.y * height,
            width: getDistance(joints.leftShoulder, joints.leftElbow) * width,
            height: 2,
            transform: [{ 
              rotate: `${getAngle(joints.leftShoulder, joints.leftElbow)}rad` 
            }],
            backgroundColor: color,
            opacity: (joints.leftShoulder.confidence + joints.leftElbow.confidence) / 2
          }
        ]} />
        
        {/* Left elbow to left wrist */}
        <View style={[
          styles.bone,
          {
            left: joints.leftElbow.x * width,
            top: joints.leftElbow.y * height,
            width: getDistance(joints.leftElbow, joints.leftWrist) * width,
            height: 2,
            transform: [{ 
              rotate: `${getAngle(joints.leftElbow, joints.leftWrist)}rad` 
            }],
            backgroundColor: color,
            opacity: (joints.leftElbow.confidence + joints.leftWrist.confidence) / 2
          }
        ]} />
        
        {/* Right shoulder to right hip */}
        <View style={[
          styles.bone,
          {
            left: joints.rightShoulder.x * width,
            top: joints.rightShoulder.y * height,
            width: getDistance(joints.rightShoulder, joints.rightHip) * width,
            height: 2,
            transform: [{ 
              rotate: `${getAngle(joints.rightShoulder, joints.rightHip)}rad` 
            }],
            backgroundColor: color,
            opacity: (joints.rightShoulder.confidence + joints.rightHip.confidence) / 2
          }
        ]} />
        
        {/* Left shoulder to left hip */}
        <View style={[
          styles.bone,
          {
            left: joints.leftShoulder.x * width,
            top: joints.leftShoulder.y * height,
            width: getDistance(joints.leftShoulder, joints.leftHip) * width,
            height: 2,
            transform: [{ 
              rotate: `${getAngle(joints.leftShoulder, joints.leftHip)}rad` 
            }],
            backgroundColor: color,
            opacity: (joints.leftShoulder.confidence + joints.leftHip.confidence) / 2
          }
        ]} />
        
        {/* Right hip to left hip */}
        <View style={[
          styles.bone,
          {
            left: joints.rightHip.x * width,
            top: joints.rightHip.y * height,
            width: getDistance(joints.rightHip, joints.leftHip) * width,
            height: 2,
            transform: [{ 
              rotate: `${getAngle(joints.rightHip, joints.leftHip)}rad` 
            }],
            backgroundColor: color,
            opacity: (joints.rightHip.confidence + joints.leftHip.confidence) / 2
          }
        ]} />
        
        {/* Right hip to right knee */}
        <View style={[
          styles.bone,
          {
            left: joints.rightHip.x * width,
            top: joints.rightHip.y * height,
            width: getDistance(joints.rightHip, joints.rightKnee) * width,
            height: 2,
            transform: [{ 
              rotate: `${getAngle(joints.rightHip, joints.rightKnee)}rad` 
            }],
            backgroundColor: color,
            opacity: (joints.rightHip.confidence + joints.rightKnee.confidence) / 2
          }
        ]} />
        
        {/* Right knee to right ankle */}
        <View style={[
          styles.bone,
          {
            left: joints.rightKnee.x * width,
            top: joints.rightKnee.y * height,
            width: getDistance(joints.rightKnee, joints.rightAnkle) * width,
            height: 2,
            transform: [{ 
              rotate: `${getAngle(joints.rightKnee, joints.rightAnkle)}rad` 
            }],
            backgroundColor: color,
            opacity: (joints.rightKnee.confidence + joints.rightAnkle.confidence) / 2
          }
        ]} />
        
        {/* Left hip to left knee */}
        <View style={[
          styles.bone,
          {
            left: joints.leftHip.x * width,
            top: joints.leftHip.y * height,
            width: getDistance(joints.leftHip, joints.leftKnee) * width,
            height: 2,
            transform: [{ 
              rotate: `${getAngle(joints.leftHip, joints.leftKnee)}rad` 
            }],
            backgroundColor: color,
            opacity: (joints.leftHip.confidence + joints.leftKnee.confidence) / 2
          }
        ]} />
        
        {/* Left knee to left ankle */}
        <View style={[
          styles.bone,
          {
            left: joints.leftKnee.x * width,
            top: joints.leftKnee.y * height,
            width: getDistance(joints.leftKnee, joints.leftAnkle) * width,
            height: 2,
            transform: [{ 
              rotate: `${getAngle(joints.leftKnee, joints.leftAnkle)}rad` 
            }],
            backgroundColor: color,
            opacity: (joints.leftKnee.confidence + joints.leftAnkle.confidence) / 2
          }
        ]} />
      </>
    );
  };
  
  // Render joints as circles
  const renderJoints = () => {
    return Object.entries(joints).map(([key, joint]) => (
      <View 
        key={key}
        style={[
          styles.joint,
          {
            left: (joint.x * width) - 4,
            top: (joint.y * height) - 4,
            backgroundColor: color,
            opacity: joint.confidence
          }
        ]}
      />
    ));
  };
  
  return (
    <View style={[styles.container, { width, height }]}>
      {renderBones()}
      {renderJoints()}
    </View>
  );
};

// Helper function to calculate distance between two joints
const getDistance = (joint1: any, joint2: any) => {
  const dx = joint2.x - joint1.x;
  const dy = joint2.y - joint1.y;
  return Math.sqrt(dx * dx + dy * dy);
};

// Helper function to calculate angle between two joints
const getAngle = (joint1: any, joint2: any) => {
  return Math.atan2(joint2.y - joint1.y, joint2.x - joint1.x);
};

const styles = StyleSheet.create({
  container: {
    position: 'absolute',
    top: 0,
    left: 0,
  },
  joint: {
    position: 'absolute',
    width: 8,
    height: 8,
    borderRadius: 4,
  },
  bone: {
    position: 'absolute',
    height: 2,
    transformOrigin: 'left',
  }
});

export default PoseOverlay;
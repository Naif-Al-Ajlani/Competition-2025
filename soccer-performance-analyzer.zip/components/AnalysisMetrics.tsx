import React from 'react';
import { View, Text, StyleSheet, ScrollView } from 'react-native';
import { AnalysisResult } from '@/types/analysis';
import colors from '@/constants/colors';
import { AlertTriangle, Check, Clock, Ruler } from 'lucide-react-native';

interface AnalysisMetricsProps {
  result: AnalysisResult;
}

const AnalysisMetrics: React.FC<AnalysisMetricsProps> = ({ result }) => {
  const { angleMetrics, timingMetrics, positionMetrics, overallScore } = result;
  
  // Calculate category scores
  const angleScore = Math.round(
    angleMetrics.filter(m => m.isGood).length / angleMetrics.length * 100
  );
  
  const timingScore = Math.round(
    timingMetrics.filter(m => m.isGood).length / timingMetrics.length * 100
  );
  
  const positionScore = Math.round(
    positionMetrics.filter(m => m.isGood).length / positionMetrics.length * 100
  );
  
  return (
    <View style={styles.container}>
      <View style={styles.scoreContainer}>
        <View style={styles.overallScoreContainer}>
          <Text style={styles.overallScoreLabel}>Overall Score</Text>
          <View style={styles.scoreCircle}>
            <Text style={styles.overallScoreValue}>{overallScore}</Text>
          </View>
        </View>
        
        <View style={styles.categoryScores}>
          <View style={styles.categoryScore}>
            <View style={[styles.categoryIcon, { backgroundColor: 'rgba(67, 97, 238, 0.2)' }]}>
              <AlertTriangle size={16} color={colors.dark.primary} />
            </View>
            <Text style={styles.categoryLabel}>Angles</Text>
            <Text style={styles.categoryValue}>{angleScore}%</Text>
          </View>
          
          <View style={styles.categoryScore}>
            <View style={[styles.categoryIcon, { backgroundColor: 'rgba(114, 9, 183, 0.2)' }]}>
              <Clock size={16} color={colors.dark.secondary} />
            </View>
            <Text style={styles.categoryLabel}>Timing</Text>
            <Text style={styles.categoryValue}>{timingScore}%</Text>
          </View>
          
          <View style={styles.categoryScore}>
            <View style={[styles.categoryIcon, { backgroundColor: 'rgba(247, 37, 133, 0.2)' }]}>
              <Ruler size={16} color={colors.dark.accent} />
            </View>
            <Text style={styles.categoryLabel}>Position</Text>
            <Text style={styles.categoryValue}>{positionScore}%</Text>
          </View>
        </View>
      </View>
      
      <ScrollView style={styles.metricsContainer}>
        {/* Angle Metrics */}
        <View style={styles.metricSection}>
          <View style={styles.sectionHeader}>
            <AlertTriangle size={18} color={colors.dark.primary} />
            <Text style={styles.sectionTitle}>Angle Metrics</Text>
          </View>
          
          {angleMetrics.map((metric, index) => (
            <View key={`angle-${index}`} style={styles.metricItem}>
              <View style={styles.metricHeader}>
                <Text style={styles.metricName}>{metric.joint}</Text>
                {metric.isGood ? (
                  <View style={styles.goodIndicator}>
                    <Check size={14} color={colors.dark.success} />
                  </View>
                ) : (
                  <View style={styles.badIndicator}>
                    <AlertTriangle size={14} color={colors.dark.error} />
                  </View>
                )}
              </View>
              
              <View style={styles.metricValues}>
                <View style={styles.metricValue}>
                  <Text style={styles.metricValueLabel}>Reference</Text>
                  <Text style={styles.metricValueText}>{metric.referenceAngle}°</Text>
                </View>
                
                <View style={styles.metricValue}>
                  <Text style={styles.metricValueLabel}>Your Angle</Text>
                  <Text style={styles.metricValueText}>{metric.userAngle}°</Text>
                </View>
                
                <View style={styles.metricValue}>
                  <Text style={styles.metricValueLabel}>Difference</Text>
                  <Text 
                    style={[
                      styles.metricValueText, 
                      metric.isGood ? styles.goodValue : styles.badValue
                    ]}
                  >
                    {metric.difference}°
                  </Text>
                </View>
              </View>
            </View>
          ))}
        </View>
        
        {/* Timing Metrics */}
        <View style={styles.metricSection}>
          <View style={styles.sectionHeader}>
            <Clock size={18} color={colors.dark.secondary} />
            <Text style={styles.sectionTitle}>Timing Metrics</Text>
          </View>
          
          {timingMetrics.map((metric, index) => (
            <View key={`timing-${index}`} style={styles.metricItem}>
              <View style={styles.metricHeader}>
                <Text style={styles.metricName}>{metric.event}</Text>
                {metric.isGood ? (
                  <View style={styles.goodIndicator}>
                    <Check size={14} color={colors.dark.success} />
                  </View>
                ) : (
                  <View style={styles.badIndicator}>
                    <AlertTriangle size={14} color={colors.dark.error} />
                  </View>
                )}
              </View>
              
              <View style={styles.metricValues}>
                <View style={styles.metricValue}>
                  <Text style={styles.metricValueLabel}>Reference</Text>
                  <Text style={styles.metricValueText}>{metric.referenceTime}ms</Text>
                </View>
                
                <View style={styles.metricValue}>
                  <Text style={styles.metricValueLabel}>Your Time</Text>
                  <Text style={styles.metricValueText}>{metric.userTime}ms</Text>
                </View>
                
                <View style={styles.metricValue}>
                  <Text style={styles.metricValueLabel}>Difference</Text>
                  <Text 
                    style={[
                      styles.metricValueText, 
                      metric.isGood ? styles.goodValue : styles.badValue
                    ]}
                  >
                    {metric.difference}ms
                  </Text>
                </View>
              </View>
            </View>
          ))}
        </View>
        
        {/* Position Metrics */}
        <View style={styles.metricSection}>
          <View style={styles.sectionHeader}>
            <Ruler size={18} color={colors.dark.accent} />
            <Text style={styles.sectionTitle}>Position Metrics</Text>
          </View>
          
          {positionMetrics.map((metric, index) => (
            <View key={`position-${index}`} style={styles.metricItem}>
              <View style={styles.metricHeader}>
                <Text style={styles.metricName}>{metric.joint}</Text>
                {metric.isGood ? (
                  <View style={styles.goodIndicator}>
                    <Check size={14} color={colors.dark.success} />
                  </View>
                ) : (
                  <View style={styles.badIndicator}>
                    <AlertTriangle size={14} color={colors.dark.error} />
                  </View>
                )}
              </View>
              
              <View style={styles.positionMetricValues}>
                <View style={styles.positionValue}>
                  <Text style={styles.metricValueLabel}>Reference Position</Text>
                  <Text style={styles.metricValueText}>
                    X: {metric.referencePosX.toFixed(2)}, Y: {metric.referencePosY.toFixed(2)}
                  </Text>
                </View>
                
                <View style={styles.positionValue}>
                  <Text style={styles.metricValueLabel}>Your Position</Text>
                  <Text style={styles.metricValueText}>
                    X: {metric.userPosX.toFixed(2)}, Y: {metric.userPosY.toFixed(2)}
                  </Text>
                </View>
                
                <View style={styles.positionValue}>
                  <Text style={styles.metricValueLabel}>Distance</Text>
                  <Text 
                    style={[
                      styles.metricValueText, 
                      metric.isGood ? styles.goodValue : styles.badValue
                    ]}
                  >
                    {(metric.distance * 100).toFixed(1)}%
                  </Text>
                </View>
              </View>
            </View>
          ))}
        </View>
      </ScrollView>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  scoreContainer: {
    backgroundColor: colors.dark.card,
    borderRadius: 12,
    padding: 16,
    marginBottom: 16,
  },
  overallScoreContainer: {
    alignItems: 'center',
    marginBottom: 16,
  },
  overallScoreLabel: {
    fontSize: 16,
    fontWeight: '600',
    color: colors.dark.text,
    marginBottom: 8,
  },
  scoreCircle: {
    width: 80,
    height: 80,
    borderRadius: 40,
    backgroundColor: colors.dark.primary,
    justifyContent: 'center',
    alignItems: 'center',
  },
  overallScoreValue: {
    fontSize: 28,
    fontWeight: 'bold',
    color: colors.dark.text,
  },
  categoryScores: {
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  categoryScore: {
    alignItems: 'center',
    flex: 1,
  },
  categoryIcon: {
    width: 32,
    height: 32,
    borderRadius: 16,
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 4,
  },
  categoryLabel: {
    fontSize: 12,
    color: colors.dark.inactive,
    marginBottom: 2,
  },
  categoryValue: {
    fontSize: 16,
    fontWeight: '600',
    color: colors.dark.text,
  },
  metricsContainer: {
    flex: 1,
  },
  metricSection: {
    backgroundColor: colors.dark.card,
    borderRadius: 12,
    padding: 16,
    marginBottom: 16,
  },
  sectionHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 12,
    gap: 8,
  },
  sectionTitle: {
    fontSize: 16,
    fontWeight: '600',
    color: colors.dark.text,
  },
  metricItem: {
    marginBottom: 12,
    borderBottomWidth: 1,
    borderBottomColor: colors.dark.border,
    paddingBottom: 12,
  },
  metricHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 8,
  },
  metricName: {
    fontSize: 14,
    fontWeight: '600',
    color: colors.dark.text,
  },
  goodIndicator: {
    backgroundColor: 'rgba(46, 196, 182, 0.2)',
    borderRadius: 4,
    padding: 2,
  },
  badIndicator: {
    backgroundColor: 'rgba(230, 57, 70, 0.2)',
    borderRadius: 4,
    padding: 2,
  },
  metricValues: {
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  metricValue: {
    flex: 1,
    alignItems: 'center',
  },
  metricValueLabel: {
    fontSize: 12,
    color: colors.dark.inactive,
    marginBottom: 4,
  },
  metricValueText: {
    fontSize: 14,
    fontWeight: '500',
    color: colors.dark.text,
  },
  goodValue: {
    color: colors.dark.success,
  },
  badValue: {
    color: colors.dark.error,
  },
  positionMetricValues: {
    flexDirection: 'column',
    gap: 8,
  },
  positionValue: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
});

export default AnalysisMetrics;
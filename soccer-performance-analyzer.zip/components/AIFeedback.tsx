import React from 'react';
import { View, Text, StyleSheet, ScrollView } from 'react-native';
import { AnalysisResult } from '@/types/analysis';
import colors from '@/constants/colors';
import { MessageSquare, ThumbsUp, AlertTriangle } from 'lucide-react-native';

interface AIFeedbackProps {
  result: AnalysisResult;
}

const AIFeedback: React.FC<AIFeedbackProps> = ({ result }) => {
  const { feedback, strengths, improvements } = result;
  
  return (
    <ScrollView style={styles.container}>
      {/* General Feedback */}
      <View style={styles.section}>
        <View style={styles.sectionHeader}>
          <MessageSquare size={20} color={colors.dark.text} />
          <Text style={styles.sectionTitle}>AI Coach Feedback</Text>
        </View>
        
        <View style={styles.feedbackContainer}>
          {feedback.map((item, index) => (
            <View key={`feedback-${index}`} style={styles.feedbackItem}>
              <Text style={styles.feedbackText}>{item}</Text>
            </View>
          ))}
        </View>
      </View>
      
      {/* Strengths */}
      <View style={styles.section}>
        <View style={styles.sectionHeader}>
          <ThumbsUp size={20} color={colors.dark.success} />
          <Text style={styles.sectionTitle}>Your Strengths</Text>
        </View>
        
        <View style={styles.strengthsContainer}>
          {strengths.map((strength, index) => (
            <View key={`strength-${index}`} style={styles.strengthItem}>
              <View style={styles.strengthBullet}>
                <Text style={styles.bulletText}>✓</Text>
              </View>
              <Text style={styles.strengthText}>{strength}</Text>
            </View>
          ))}
        </View>
      </View>
      
      {/* Areas for Improvement */}
      <View style={styles.section}>
        <View style={styles.sectionHeader}>
          <AlertTriangle size={20} color={colors.dark.error} />
          <Text style={styles.sectionTitle}>Areas for Improvement</Text>
        </View>
        
        <View style={styles.improvementsContainer}>
          {improvements.map((improvement, index) => (
            <View key={`improvement-${index}`} style={styles.improvementItem}>
              <View style={styles.improvementBullet}>
                <Text style={styles.bulletText}>!</Text>
              </View>
              <Text style={styles.improvementText}>{improvement}</Text>
            </View>
          ))}
        </View>
      </View>
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  section: {
    backgroundColor: colors.dark.card,
    borderRadius: 12,
    padding: 16,
    marginBottom: 16,
  },
  sectionHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 16,
    gap: 8,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: '600',
    color: colors.dark.text,
  },
  feedbackContainer: {
    gap: 12,
  },
  feedbackItem: {
    backgroundColor: 'rgba(67, 97, 238, 0.1)',
    borderRadius: 8,
    padding: 12,
    borderLeftWidth: 3,
    borderLeftColor: colors.dark.primary,
  },
  feedbackText: {
    fontSize: 15,
    color: colors.dark.text,
    lineHeight: 22,
  },
  strengthsContainer: {
    gap: 12,
  },
  strengthItem: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    gap: 12,
  },
  strengthBullet: {
    width: 24,
    height: 24,
    borderRadius: 12,
    backgroundColor: 'rgba(46, 196, 182, 0.2)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  bulletText: {
    fontSize: 14,
    fontWeight: 'bold',
    color: colors.dark.text,
  },
  strengthText: {
    flex: 1,
    fontSize: 15,
    color: colors.dark.text,
    lineHeight: 22,
  },
  improvementsContainer: {
    gap: 12,
  },
  improvementItem: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    gap: 12,
  },
  improvementBullet: {
    width: 24,
    height: 24,
    borderRadius: 12,
    backgroundColor: 'rgba(230, 57, 70, 0.2)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  improvementText: {
    flex: 1,
    fontSize: 15,
    color: colors.dark.text,
    lineHeight: 22,
  },
});

export default AIFeedback;
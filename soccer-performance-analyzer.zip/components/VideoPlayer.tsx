import React, { useState } from 'react';
import { View, Text, StyleSheet, Pressable, Platform } from 'react-native';
import { Image } from 'expo-image';
import { Play, Pause, SkipBack, SkipForward } from 'lucide-react-native';
import colors from '@/constants/colors';
import { VideoSource } from '@/types/comparison';

interface VideoPlayerProps {
  video: VideoSource;
  style?: object;
}

export default function VideoPlayer({ video, style }: VideoPlayerProps) {
  const [isPlaying, setIsPlaying] = useState(false);
  const [progress, setProgress] = useState(0);

  // In a real app, we would use expo-av to play videos
  // For this demo, we'll just show the thumbnail and simulate playback
  const togglePlayback = () => {
    setIsPlaying(!isPlaying);
    
    // Simulate progress for demo purposes
    if (!isPlaying) {
      const interval = setInterval(() => {
        setProgress(prev => {
          if (prev >= 1) {
            clearInterval(interval);
            setIsPlaying(false);
            return 0;
          }
          return prev + 0.01;
        });
      }, 100);
    }
  };

  const resetPlayback = () => {
    setProgress(0);
    setIsPlaying(false);
  };

  return (
    <View style={[styles.container, style]}>
      <View style={styles.videoContainer}>
        <Image
          source={{ uri: video.thumbnail }}
          style={styles.thumbnail}
          contentFit="cover"
        />
        
        {/* Progress bar */}
        <View style={styles.progressContainer}>
          <View 
            style={[
              styles.progressBar, 
              { width: `${progress * 100}%`, backgroundColor: colors.dark.primary }
            ]} 
          />
        </View>
        
        {/* Play button overlay */}
        {!isPlaying && (
          <Pressable 
            style={styles.playOverlay}
            onPress={togglePlayback}
          >
            <View style={styles.playButton}>
              <Play size={24} color={colors.dark.text} />
            </View>
          </Pressable>
        )}
      </View>
      
      {/* Controls */}
      <View style={styles.controls}>
        <Pressable onPress={resetPlayback}>
          <SkipBack size={24} color={colors.dark.text} />
        </Pressable>
        
        <Pressable onPress={togglePlayback}>
          {isPlaying ? (
            <Pause size={32} color={colors.dark.text} />
          ) : (
            <Play size={32} color={colors.dark.text} />
          )}
        </Pressable>
        
        <Pressable>
          <SkipForward size={24} color={colors.dark.text} />
        </Pressable>
      </View>
      
      <Text style={styles.title}>{video.title}</Text>
      {video.duration && (
        <Text style={styles.duration}>{video.duration}s</Text>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    borderRadius: 12,
    overflow: 'hidden',
    backgroundColor: colors.dark.card,
  },
  videoContainer: {
    position: 'relative',
    aspectRatio: 16/9,
    borderRadius: 8,
    overflow: 'hidden',
  },
  thumbnail: {
    width: '100%',
    height: '100%',
  },
  playOverlay: {
    ...StyleSheet.absoluteFillObject,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: 'rgba(0,0,0,0.3)',
  },
  playButton: {
    width: 50,
    height: 50,
    borderRadius: 25,
    backgroundColor: 'rgba(255,255,255,0.8)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  progressContainer: {
    position: 'absolute',
    bottom: 0,
    left: 0,
    right: 0,
    height: 4,
    backgroundColor: 'rgba(255,255,255,0.2)',
  },
  progressBar: {
    height: '100%',
  },
  controls: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    alignItems: 'center',
    paddingVertical: 12,
  },
  title: {
    fontSize: 16,
    fontWeight: '600',
    color: colors.dark.text,
    paddingHorizontal: 12,
    paddingBottom: 4,
  },
  duration: {
    fontSize: 14,
    color: colors.dark.inactive,
    paddingHorizontal: 12,
    paddingBottom: 12,
  }
});
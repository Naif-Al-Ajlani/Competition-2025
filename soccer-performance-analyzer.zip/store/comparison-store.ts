import { create } from 'zustand';
import { persist, createJSONStorage } from 'zustand/middleware';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { Comparison, VideoSource } from '@/types/comparison';
import { mockComparisons } from '@/mocks/comparisons';

// Define a type for videos without id and createdAt
export type VideoSourceInput = Omit<VideoSource, 'id' | 'createdAt'>;

interface ComparisonState {
  comparisons: Comparison[];
  selectedComparison: Comparison | null;
  isLoading: boolean;
  error: string | null;
  
  // Actions
  fetchComparisons: () => Promise<void>;
  getComparisonById: (id: string) => Comparison | undefined;
  setSelectedComparison: (comparison: Comparison | null) => void;
  addComparison: (comparison: {
    title: string;
    description?: string;
    videos: {
      reference?: VideoSourceInput;
      training?: VideoSourceInput;
    };
    notes?: string[];
    tags?: string[];
  }) => void;
  updateComparison: (id: string, updates: Partial<Omit<Comparison, 'id' | 'createdAt' | 'updatedAt'>> & {
    videos?: {
      reference?: VideoSourceInput | VideoSource;
      training?: VideoSourceInput | VideoSource;
    }
  }) => void;
  deleteComparison: (id: string) => void;
  addVideoToComparison: (comparisonId: string, videoType: 'reference' | 'training', video: VideoSourceInput) => void;
}

// Helper function to ensure a video has id and createdAt
const processVideo = (video?: VideoSourceInput | VideoSource): VideoSource | undefined => {
  if (!video) return undefined;
  
  // If it already has id and createdAt, assume it's a complete VideoSource
  if ('id' in video && 'createdAt' in video && video.id && video.createdAt) {
    return video as VideoSource;
  }
  
  // Otherwise, add the missing properties
  return {
    ...video,
    id: Date.now().toString(),
    createdAt: Date.now()
  };
};

// Create the store without persistence for now
export const useComparisonStore = create<ComparisonState>((set, get) => ({
  comparisons: mockComparisons,
  selectedComparison: null,
  isLoading: false,
  error: null,

  fetchComparisons: async () => {
    set({ isLoading: true, error: null });
    try {
      // In a real app, this would be an API call
      // For now, we'll use mock data
      set({ comparisons: mockComparisons, isLoading: false });
    } catch (error) {
      set({ error: 'Failed to fetch comparisons', isLoading: false });
    }
  },

  getComparisonById: (id) => {
    return get().comparisons.find(c => c.id === id);
  },

  setSelectedComparison: (comparison) => {
    set({ selectedComparison: comparison });
  },

  addComparison: (comparison) => {
    // Process videos to ensure they have id and createdAt
    const processedVideos = {
      reference: processVideo(comparison.videos.reference),
      training: processVideo(comparison.videos.training)
    };

    const newComparison: Comparison = {
      ...comparison,
      id: Date.now().toString(),
      createdAt: Date.now(),
      updatedAt: Date.now(),
      videos: processedVideos
    };
    
    // Update state without persistence
    set(state => ({
      comparisons: [newComparison, ...state.comparisons]
    }));
  },

  updateComparison: (id, updates) => {
    set(state => ({
      comparisons: state.comparisons.map(c => {
        if (c.id !== id) return c;
        
        // Process videos if they exist in the updates
        const updatedVideos = updates.videos ? {
          reference: processVideo(updates.videos.reference) || c.videos.reference,
          training: processVideo(updates.videos.training) || c.videos.training
        } : c.videos;
        
        return { 
          ...c, 
          ...updates, 
          videos: updatedVideos,
          updatedAt: Date.now() 
        };
      })
    }));
  },

  deleteComparison: (id) => {
    set(state => ({
      comparisons: state.comparisons.filter(c => c.id !== id),
      selectedComparison: state.selectedComparison?.id === id ? null : state.selectedComparison
    }));
  },

  addVideoToComparison: (comparisonId, videoType, video) => {
    const newVideo = processVideo(video);

    set(state => ({
      comparisons: state.comparisons.map(c => 
        c.id === comparisonId 
          ? { 
              ...c, 
              videos: { 
                ...c.videos, 
                [videoType]: newVideo 
              },
              updatedAt: Date.now()
            } 
          : c
      )
    }));
  }
}));

// Note: We've removed persistence completely to avoid storage quota issues
// In a real app, you would implement a more sophisticated storage strategy
// such as storing only IDs and loading data on demand, or using a different storage mechanism
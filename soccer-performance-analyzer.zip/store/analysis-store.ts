import { create } from 'zustand';
import { persist, createJSONStorage } from 'zustand/middleware';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { AnalysisData, AnalysisResult } from '@/types/analysis';
import { mockAnalysisData } from '@/mocks/analysis-data';

interface AnalysisState {
  analyses: AnalysisData[];
  currentAnalysis: AnalysisData | null;
  isLoading: boolean;
  error: string | null;
  
  // Actions
  fetchAnalyses: () => Promise<void>;
  getAnalysisByComparisonId: (comparisonId: string) => AnalysisData | undefined;
  setCurrentAnalysis: (analysis: AnalysisData | null) => void;
  startAnalysis: (comparisonId: string) => Promise<string>;
  cancelAnalysis: (analysisId: string) => void;
}

export const useAnalysisStore = create<AnalysisState>()(
  persist(
    (set, get) => ({
      analyses: [],
      currentAnalysis: null,
      isLoading: false,
      error: null,

      fetchAnalyses: async () => {
        set({ isLoading: true, error: null });
        try {
          // In a real app, this would be an API call
          // For now, we'll use mock data
          set({ analyses: mockAnalysisData, isLoading: false });
        } catch (error) {
          set({ error: 'Failed to fetch analyses', isLoading: false });
        }
      },

      getAnalysisByComparisonId: (comparisonId) => {
        return get().analyses.find(a => a.comparisonId === comparisonId);
      },

      setCurrentAnalysis: (analysis) => {
        set({ currentAnalysis: analysis });
      },

      startAnalysis: async (comparisonId) => {
        set({ isLoading: true, error: null });
        
        try {
          // In a real app, this would start an analysis job on the server
          // For now, we'll simulate a new analysis
          const newAnalysisId = `analysis-${Date.now()}`;
          
          const newAnalysis: AnalysisData = {
            id: newAnalysisId,
            comparisonId,
            createdAt: Date.now(),
            status: 'pending'
          };
          
          set(state => ({
            analyses: [newAnalysis, ...state.analyses],
            isLoading: false
          }));
          
          // Simulate analysis completion after a delay
          setTimeout(() => {
            set(state => ({
              analyses: state.analyses.map(a => 
                a.id === newAnalysisId 
                  ? { 
                      ...a, 
                      status: 'completed',
                      result: mockAnalysisData.find(ma => ma.comparisonId === comparisonId)?.result
                    } 
                  : a
              )
            }));
          }, 3000);
          
          return newAnalysisId;
        } catch (error) {
          set({ error: 'Failed to start analysis', isLoading: false });
          throw error;
        }
      },

      cancelAnalysis: (analysisId) => {
        set(state => ({
          analyses: state.analyses.map(a => 
            a.id === analysisId && a.status === 'pending'
              ? { ...a, status: 'failed' } 
              : a
          )
        }));
      }
    }),
    {
      name: 'analysis-storage',
      storage: createJSONStorage(() => AsyncStorage)
    }
  )
);
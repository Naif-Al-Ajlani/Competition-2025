import React, { useEffect, useState } from 'react';
import { View, Text, StyleSheet, ScrollView, Pressable, Alert } from 'react-native';
import { useLocalSearchParams, useRouter, Stack } from 'expo-router';
import { ArrowLeft, Edit, Trash2, MessageSquare, Tag, BarChart2, Brain, Play } from 'lucide-react-native';
import { useComparisonStore } from '@/store/comparison-store';
import { useAnalysisStore } from '@/store/analysis-store';
import VideoPlayer from '@/components/VideoPlayer';
import EnhancedVideoPlayer from '@/components/EnhancedVideoPlayer';
import colors from '@/constants/colors';

export default function ComparisonDetailScreen() {
  const { id } = useLocalSearchParams();
  const router = useRouter();
  const { getComparisonById, deleteComparison } = useComparisonStore();
  const { getAnalysisByComparisonId, startAnalysis } = useAnalysisStore();
  const [comparison, setComparison] = useState(getComparisonById(id as string));
  const [analysis, setAnalysis] = useState(getAnalysisByComparisonId(id as string));
  const [activeTab, setActiveTab] = useState<'videos' | 'analysis'>('videos');
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  
  useEffect(() => {
    if (!comparison) {
      // If comparison not found, go back to comparisons list
      router.replace('/comparisons');
    }
  }, [comparison, router]);
  
  useEffect(() => {
    // Update analysis when it changes
    setAnalysis(getAnalysisByComparisonId(id as string));
  }, [id, getAnalysisByComparisonId]);
  
  if (!comparison) {
    return null;
  }
  
  const handleDelete = () => {
    Alert.alert(
      "Delete Comparison",
      "Are you sure you want to delete this comparison? This action cannot be undone.",
      [
        {
          text: "Cancel",
          style: "cancel"
        },
        {
          text: "Delete",
          style: "destructive",
          onPress: () => {
            deleteComparison(comparison.id);
            router.replace('/comparisons');
          }
        }
      ]
    );
  };
  
  const handleEdit = () => {
    router.push(`/edit/${comparison.id}`);
  };
  
  const handleStartAnalysis = async () => {
    if (!comparison.videos.reference || !comparison.videos.training) {
      Alert.alert(
        "Missing Videos",
        "You need both a reference video and a training video to perform analysis."
      );
      return;
    }
    
    setIsAnalyzing(true);
    try {
      await startAnalysis(comparison.id);
      setActiveTab('analysis');
      // Analysis will be updated via the useEffect hook
    } catch (error) {
      Alert.alert("Error", "Failed to start analysis. Please try again.");
    } finally {
      setIsAnalyzing(false);
    }
  };
  
  const navigateToAnalysis = () => {
    if (analysis) {
      router.push(`/analysis/${analysis.id}`);
    }
  };
  
  const formattedDate = new Date(comparison.updatedAt).toLocaleDateString();
  
  return (
    <>
      <Stack.Screen 
        options={{
          title: comparison.title,
          headerRight: () => (
            <View style={styles.headerButtons}>
              <Pressable style={styles.headerButton} onPress={handleEdit}>
                <Edit size={20} color={colors.dark.text} />
              </Pressable>
              <Pressable style={styles.headerButton} onPress={handleDelete}>
                <Trash2 size={20} color={colors.dark.text} />
              </Pressable>
            </View>
          ),
        }}
      />
      
      <View style={styles.container}>
        {/* Metadata */}
        <View style={styles.metadataContainer}>
          <Text style={styles.date}>Last updated: {formattedDate}</Text>
          
          {comparison.description && (
            <Text style={styles.description}>{comparison.description}</Text>
          )}
          
          {comparison.tags && comparison.tags.length > 0 && (
            <View style={styles.tagsContainer}>
              <Tag size={16} color={colors.dark.inactive} />
              <Text style={styles.tags}>{comparison.tags.join(', ')}</Text>
            </View>
          )}
        </View>
        
        {/* Tabs */}
        <View style={styles.tabsContainer}>
          <Pressable 
            style={[
              styles.tab, 
              activeTab === 'videos' && styles.activeTab
            ]}
            onPress={() => setActiveTab('videos')}
          >
            <Play size={18} color={activeTab === 'videos' ? colors.dark.primary : colors.dark.inactive} />
            <Text 
              style={[
                styles.tabText,
                activeTab === 'videos' && styles.activeTabText
              ]}
            >
              Videos
            </Text>
          </Pressable>
          
          <Pressable 
            style={[
              styles.tab, 
              activeTab === 'analysis' && styles.activeTab
            ]}
            onPress={() => setActiveTab('analysis')}
          >
            <BarChart2 size={18} color={activeTab === 'analysis' ? colors.dark.primary : colors.dark.inactive} />
            <Text 
              style={[
                styles.tabText,
                activeTab === 'analysis' && styles.activeTabText
              ]}
            >
              Analysis
            </Text>
          </Pressable>
        </View>
        
        <ScrollView style={styles.content} contentContainerStyle={styles.scrollContent}>
          {activeTab === 'videos' ? (
            /* Videos Tab */
            <View style={styles.videosContainer}>
              {comparison.videos.reference ? (
                <View style={styles.videoSection}>
                  <View style={styles.videoHeader}>
                    <Text style={styles.videoTitle}>Reference Video</Text>
                    <View style={[styles.videoBadge, { backgroundColor: colors.dark.primary }]}>
                      <Text style={styles.videoBadgeText}>PRO</Text>
                    </View>
                  </View>
                  <VideoPlayer video={comparison.videos.reference} />
                </View>
              ) : (
                <View style={styles.emptyVideoSection}>
                  <Text style={styles.emptyVideoText}>No reference video added</Text>
                  <Pressable style={styles.addVideoButton} onPress={handleEdit}>
                    <Text style={styles.addVideoButtonText}>Add Reference Video</Text>
                  </Pressable>
                </View>
              )}
              
              {comparison.videos.training ? (
                <View style={styles.videoSection}>
                  <View style={styles.videoHeader}>
                    <Text style={styles.videoTitle}>Your Training</Text>
                    <View style={[styles.videoBadge, { backgroundColor: colors.dark.secondary }]}>
                      <Text style={styles.videoBadgeText}>YOU</Text>
                    </View>
                  </View>
                  <VideoPlayer video={comparison.videos.training} />
                </View>
              ) : (
                <View style={styles.emptyVideoSection}>
                  <Text style={styles.emptyVideoText}>No training video added</Text>
                  <Pressable style={styles.addVideoButton} onPress={handleEdit}>
                    <Text style={styles.addVideoButtonText}>Add Training Video</Text>
                  </Pressable>
                </View>
              )}
              
              {/* Analysis Button */}
              {comparison.videos.reference && comparison.videos.training && (
                <Pressable 
                  style={styles.analyzeButton}
                  onPress={handleStartAnalysis}
                  disabled={isAnalyzing}
                >
                  <Brain size={20} color={colors.dark.text} />
                  <Text style={styles.analyzeButtonText}>
                    {isAnalyzing ? "Analyzing..." : "Analyze Technique"}
                  </Text>
                </Pressable>
              )}
              
              {/* Notes */}
              <View style={styles.notesContainer}>
                <View style={styles.sectionHeader}>
                  <MessageSquare size={20} color={colors.dark.text} />
                  <Text style={styles.sectionTitle}>Notes</Text>
                </View>
                
                {comparison.notes && comparison.notes.length > 0 ? (
                  <View style={styles.notesList}>
                    {comparison.notes.map((note, index) => (
                      <View key={index} style={styles.noteItem}>
                        <Text style={styles.noteNumber}>{index + 1}</Text>
                        <Text style={styles.noteText}>{note}</Text>
                      </View>
                    ))}
                  </View>
                ) : (
                  <View style={styles.emptyNotes}>
                    <Text style={styles.emptyNotesText}>
                      No notes added yet. Add notes to track your progress and improvements.
                    </Text>
                    <Pressable style={styles.addNoteButton} onPress={handleEdit}>
                      <Text style={styles.addNoteButtonText}>Add Note</Text>
                    </Pressable>
                  </View>
                )}
              </View>
            </View>
          ) : (
            /* Analysis Tab */
            <View style={styles.analysisContainer}>
              {analysis && analysis.status === 'completed' ? (
                <Pressable 
                  style={styles.analysisCard}
                  onPress={navigateToAnalysis}
                >
                  <View style={styles.analysisHeader}>
                    <Text style={styles.analysisTitle}>AI Analysis Results</Text>
                    <View style={styles.scoreContainer}>
                      <Text style={styles.scoreLabel}>Score</Text>
                      <View style={styles.scoreCircle}>
                        <Text style={styles.scoreValue}>{analysis.result?.overallScore || 0}</Text>
                      </View>
                    </View>
                  </View>
                  
                  <View style={styles.analysisPreview}>
                    <Text style={styles.previewTitle}>Key Findings:</Text>
                    {analysis.result?.feedback.slice(0, 2).map((feedback, index) => (
                      <View key={index} style={styles.feedbackItem}>
                        <Text style={styles.feedbackText}>{feedback}</Text>
                      </View>
                    ))}
                    
                    <Text style={styles.viewMoreText}>Tap to view detailed analysis</Text>
                  </View>
                </Pressable>
              ) : analysis && (analysis.status === 'pending' || analysis.status === 'processing') ? (
                <View style={styles.analysisLoading}>
                  <Brain size={48} color={colors.dark.primary} />
                  <Text style={styles.loadingTitle}>Analysis in Progress</Text>
                  <Text style={styles.loadingText}>
                    Our AI is analyzing your technique. This may take a few moments.
                  </Text>
                </View>
              ) : (
                <View style={styles.noAnalysis}>
                  <Brain size={48} color={colors.dark.inactive} />
                  <Text style={styles.noAnalysisTitle}>No Analysis Available</Text>
                  <Text style={styles.noAnalysisText}>
                    Run an analysis to get AI-powered feedback on your technique.
                  </Text>
                  
                  {comparison.videos.reference && comparison.videos.training && (
                    <Pressable 
                      style={styles.analyzeButton}
                      onPress={handleStartAnalysis}
                      disabled={isAnalyzing}
                    >
                      <Brain size={20} color={colors.dark.text} />
                      <Text style={styles.analyzeButtonText}>
                        {isAnalyzing ? "Analyzing..." : "Start Analysis"}
                      </Text>
                    </Pressable>
                  )}
                </View>
              )}
            </View>
          )}
        </ScrollView>
      </View>
    </>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.dark.background,
  },
  metadataContainer: {
    padding: 16,
    paddingBottom: 0,
  },
  date: {
    fontSize: 14,
    color: colors.dark.inactive,
    marginBottom: 8,
  },
  description: {
    fontSize: 16,
    color: colors.dark.text,
    marginBottom: 12,
    lineHeight: 22,
  },
  tagsContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    marginBottom: 16,
  },
  tags: {
    fontSize: 14,
    color: colors.dark.inactive,
  },
  tabsContainer: {
    flexDirection: 'row',
    borderBottomWidth: 1,
    borderBottomColor: colors.dark.border,
    marginHorizontal: 16,
  },
  tab: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 12,
    paddingHorizontal: 16,
    gap: 8,
  },
  activeTab: {
    borderBottomWidth: 2,
    borderBottomColor: colors.dark.primary,
  },
  tabText: {
    fontSize: 16,
    color: colors.dark.inactive,
  },
  activeTabText: {
    color: colors.dark.primary,
    fontWeight: '600',
  },
  content: {
    flex: 1,
  },
  scrollContent: {
    padding: 16,
    paddingBottom: 40,
  },
  headerButtons: {
    flexDirection: 'row',
    gap: 16,
  },
  headerButton: {
    padding: 4,
  },
  videosContainer: {
    gap: 24,
  },
  videoSection: {
    gap: 8,
  },
  videoHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    marginBottom: 4,
  },
  videoTitle: {
    fontSize: 18,
    fontWeight: '600',
    color: colors.dark.text,
  },
  videoBadge: {
    paddingHorizontal: 8,
    paddingVertical: 2,
    borderRadius: 4,
  },
  videoBadgeText: {
    fontSize: 12,
    fontWeight: 'bold',
    color: colors.dark.text,
  },
  emptyVideoSection: {
    backgroundColor: colors.dark.card,
    borderRadius: 12,
    padding: 24,
    alignItems: 'center',
  },
  emptyVideoText: {
    fontSize: 16,
    color: colors.dark.inactive,
    marginBottom: 12,
  },
  addVideoButton: {
    backgroundColor: colors.dark.primary,
    paddingVertical: 8,
    paddingHorizontal: 16,
    borderRadius: 8,
  },
  addVideoButtonText: {
    fontSize: 14,
    fontWeight: '600',
    color: colors.dark.text,
  },
  analyzeButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: colors.dark.primary,
    borderRadius: 12,
    padding: 16,
    gap: 8,
  },
  analyzeButtonText: {
    fontSize: 16,
    fontWeight: '600',
    color: colors.dark.text,
  },
  notesContainer: {
    marginBottom: 24,
  },
  sectionHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    marginBottom: 16,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: '600',
    color: colors.dark.text,
  },
  notesList: {
    gap: 12,
  },
  noteItem: {
    flexDirection: 'row',
    backgroundColor: colors.dark.card,
    borderRadius: 12,
    padding: 16,
    alignItems: 'flex-start',
    gap: 12,
  },
  noteNumber: {
    width: 24,
    height: 24,
    borderRadius: 12,
    backgroundColor: colors.dark.primary,
    textAlign: 'center',
    textAlignVertical: 'center',
    fontSize: 14,
    fontWeight: 'bold',
    color: colors.dark.text,
  },
  noteText: {
    flex: 1,
    fontSize: 16,
    color: colors.dark.text,
    lineHeight: 22,
  },
  emptyNotes: {
    backgroundColor: colors.dark.card,
    borderRadius: 12,
    padding: 24,
    alignItems: 'center',
  },
  emptyNotesText: {
    fontSize: 16,
    color: colors.dark.inactive,
    textAlign: 'center',
    marginBottom: 16,
  },
  addNoteButton: {
    backgroundColor: colors.dark.primary,
    paddingVertical: 8,
    paddingHorizontal: 16,
    borderRadius: 8,
  },
  addNoteButtonText: {
    fontSize: 14,
    fontWeight: '600',
    color: colors.dark.text,
  },
  analysisContainer: {
    flex: 1,
  },
  analysisCard: {
    backgroundColor: colors.dark.card,
    borderRadius: 12,
    padding: 16,
    marginBottom: 16,
  },
  analysisHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 16,
  },
  analysisTitle: {
    fontSize: 18,
    fontWeight: '600',
    color: colors.dark.text,
  },
  scoreContainer: {
    alignItems: 'center',
  },
  scoreLabel: {
    fontSize: 12,
    color: colors.dark.inactive,
    marginBottom: 4,
  },
  scoreCircle: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: colors.dark.primary,
    justifyContent: 'center',
    alignItems: 'center',
  },
  scoreValue: {
    fontSize: 16,
    fontWeight: 'bold',
    color: colors.dark.text,
  },
  analysisPreview: {
    gap: 8,
  },
  previewTitle: {
    fontSize: 16,
    fontWeight: '600',
    color: colors.dark.text,
    marginBottom: 4,
  },
  feedbackItem: {
    backgroundColor: 'rgba(67, 97, 238, 0.1)',
    borderRadius: 8,
    padding: 12,
    borderLeftWidth: 3,
    borderLeftColor: colors.dark.primary,
  },
  feedbackText: {
    fontSize: 14,
    color: colors.dark.text,
  },
  viewMoreText: {
    fontSize: 14,
    color: colors.dark.primary,
    textAlign: 'center',
    marginTop: 12,
  },
  analysisLoading: {
    backgroundColor: colors.dark.card,
    borderRadius: 12,
    padding: 24,
    alignItems: 'center',
    justifyContent: 'center',
  },
  loadingTitle: {
    fontSize: 18,
    fontWeight: '600',
    color: colors.dark.text,
    marginTop: 16,
    marginBottom: 8,
  },
  loadingText: {
    fontSize: 16,
    color: colors.dark.inactive,
    textAlign: 'center',
  },
  noAnalysis: {
    backgroundColor: colors.dark.card,
    borderRadius: 12,
    padding: 24,
    alignItems: 'center',
    justifyContent: 'center',
    gap: 12,
  },
  noAnalysisTitle: {
    fontSize: 18,
    fontWeight: '600',
    color: colors.dark.text,
    marginTop: 8,
  },
  noAnalysisText: {
    fontSize: 16,
    color: colors.dark.inactive,
    textAlign: 'center',
    marginBottom: 8,
  },
});
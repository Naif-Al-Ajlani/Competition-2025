import React, { useEffect } from 'react';
import { View, StyleSheet, FlatList, Text, Pressable } from 'react-native';
import { useRouter } from 'expo-router';
import { Plus } from 'lucide-react-native';
import { useComparisonStore } from '@/store/comparison-store';
import ComparisonCard from '@/components/ComparisonCard';
import EmptyState from '@/components/EmptyState';
import colors from '@/constants/colors';

export default function ComparisonsScreen() {
  const router = useRouter();
  const { comparisons, fetchComparisons, isLoading } = useComparisonStore();
  
  useEffect(() => {
    fetchComparisons();
  }, []);
  
  const navigateToCreate = () => {
    router.push('/create');
  };
  
  if (comparisons.length === 0) {
    return (
      <View style={styles.container}>
        <EmptyState
          title="No Comparisons Yet"
          description="Create your first video comparison to start analyzing and improving your technique."
          actionLabel="Create Comparison"
          onAction={navigateToCreate}
        />
      </View>
    );
  }
  
  return (
    <View style={styles.container}>
      <FlatList
        data={comparisons}
        keyExtractor={(item) => item.id}
        renderItem={({ item }) => <ComparisonCard comparison={item} />}
        contentContainerStyle={styles.listContent}
        ListHeaderComponent={
          <View style={styles.header}>
            <Text style={styles.title}>Your Comparisons</Text>
            <Pressable style={styles.createButton} onPress={navigateToCreate}>
              <Plus size={20} color={colors.dark.text} />
              <Text style={styles.createButtonText}>New</Text>
            </Pressable>
          </View>
        }
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.dark.background,
  },
  listContent: {
    padding: 16,
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 16,
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    color: colors.dark.text,
  },
  createButton: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: colors.dark.primary,
    paddingVertical: 8,
    paddingHorizontal: 12,
    borderRadius: 8,
    gap: 4,
  },
  createButtonText: {
    fontSize: 14,
    fontWeight: '600',
    color: colors.dark.text,
  },
});
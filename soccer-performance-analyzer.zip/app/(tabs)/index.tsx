import React, { useEffect } from 'react';
import { View, Text, StyleSheet, ScrollView, Pressable } from 'react-native';
import { useRouter } from 'expo-router';
import { ChevronRight, Plus } from 'lucide-react-native';
import { useComparisonStore } from '@/store/comparison-store';
import ComparisonCard from '@/components/ComparisonCard';
import colors from '@/constants/colors';

export default function HomeScreen() {
  const router = useRouter();
  const { comparisons, fetchComparisons } = useComparisonStore();
  
  useEffect(() => {
    fetchComparisons();
  }, []);
  
  const recentComparisons = comparisons.slice(0, 3);
  
  const navigateToCreate = () => {
    router.push('/create');
  };
  
  const navigateToAllComparisons = () => {
    router.push('/comparisons');
  };
  
  return (
    <ScrollView style={styles.container} contentContainerStyle={styles.content}>
      <View style={styles.header}>
        <Text style={styles.title}>Video Coach</Text>
        <Text style={styles.subtitle}>Compare and improve your technique</Text>
      </View>
      
      <View style={styles.createCardContainer}>
        <Pressable style={styles.createCard} onPress={navigateToCreate}>
          <View style={styles.createCardContent}>
            <Text style={styles.createCardTitle}>Create New Comparison</Text>
            <Text style={styles.createCardDescription}>
              Upload or record videos to compare and analyze
            </Text>
          </View>
          <View style={styles.createCardIcon}>
            <Plus size={24} color={colors.dark.text} />
          </View>
        </Pressable>
      </View>
      
      <View style={styles.sectionHeader}>
        <Text style={styles.sectionTitle}>Recent Comparisons</Text>
        <Pressable style={styles.seeAllButton} onPress={navigateToAllComparisons}>
          <Text style={styles.seeAllText}>See all</Text>
          <ChevronRight size={16} color={colors.dark.primary} />
        </Pressable>
      </View>
      
      {recentComparisons.length > 0 ? (
        <View style={styles.comparisonsContainer}>
          {recentComparisons.map(comparison => (
            <ComparisonCard key={comparison.id} comparison={comparison} />
          ))}
        </View>
      ) : (
        <View style={styles.emptyContainer}>
          <Text style={styles.emptyText}>No comparisons yet</Text>
          <Text style={styles.emptySubtext}>
            Create your first comparison to get started
          </Text>
        </View>
      )}
      
      <View style={styles.tipsContainer}>
        <Text style={styles.tipsTitle}>Tips for Better Comparisons</Text>
        <View style={styles.tipCard}>
          <Text style={styles.tipNumber}>1</Text>
          <View style={styles.tipContent}>
            <Text style={styles.tipTitle}>Use good lighting</Text>
            <Text style={styles.tipDescription}>
              Record in well-lit areas for clearer video analysis
            </Text>
          </View>
        </View>
        
        <View style={styles.tipCard}>
          <Text style={styles.tipNumber}>2</Text>
          <View style={styles.tipContent}>
            <Text style={styles.tipTitle}>Find the right angle</Text>
            <Text style={styles.tipDescription}>
              Position the camera to capture your full movement
            </Text>
          </View>
        </View>
        
        <View style={styles.tipCard}>
          <Text style={styles.tipNumber}>3</Text>
          <View style={styles.tipContent}>
            <Text style={styles.tipTitle}>Use slow motion</Text>
            <Text style={styles.tipDescription}>
              Slow down videos to analyze technique in detail
            </Text>
          </View>
        </View>
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.dark.background,
  },
  content: {
    padding: 16,
  },
  header: {
    marginBottom: 24,
  },
  title: {
    fontSize: 28,
    fontWeight: 'bold',
    color: colors.dark.text,
    marginBottom: 4,
  },
  subtitle: {
    fontSize: 16,
    color: colors.dark.inactive,
  },
  createCardContainer: {
    marginBottom: 24,
  },
  createCard: {
    backgroundColor: colors.dark.primary,
    borderRadius: 16,
    padding: 20,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  createCardContent: {
    flex: 1,
  },
  createCardTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: colors.dark.text,
    marginBottom: 4,
  },
  createCardDescription: {
    fontSize: 14,
    color: 'rgba(255, 255, 255, 0.8)',
  },
  createCardIcon: {
    width: 48,
    height: 48,
    borderRadius: 24,
    backgroundColor: 'rgba(255, 255, 255, 0.2)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  sectionHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 16,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: '600',
    color: colors.dark.text,
  },
  seeAllButton: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  seeAllText: {
    fontSize: 14,
    color: colors.dark.primary,
  },
  comparisonsContainer: {
    marginBottom: 24,
  },
  emptyContainer: {
    backgroundColor: colors.dark.card,
    borderRadius: 12,
    padding: 24,
    alignItems: 'center',
    marginBottom: 24,
  },
  emptyText: {
    fontSize: 16,
    fontWeight: '600',
    color: colors.dark.text,
    marginBottom: 4,
  },
  emptySubtext: {
    fontSize: 14,
    color: colors.dark.inactive,
    textAlign: 'center',
  },
  tipsContainer: {
    marginBottom: 24,
  },
  tipsTitle: {
    fontSize: 18,
    fontWeight: '600',
    color: colors.dark.text,
    marginBottom: 16,
  },
  tipCard: {
    backgroundColor: colors.dark.card,
    borderRadius: 12,
    padding: 16,
    flexDirection: 'row',
    marginBottom: 12,
  },
  tipNumber: {
    width: 32,
    height: 32,
    borderRadius: 16,
    backgroundColor: colors.dark.primary,
    textAlign: 'center',
    textAlignVertical: 'center',
    fontSize: 16,
    fontWeight: 'bold',
    color: colors.dark.text,
    marginRight: 12,
  },
  tipContent: {
    flex: 1,
  },
  tipTitle: {
    fontSize: 16,
    fontWeight: '600',
    color: colors.dark.text,
    marginBottom: 4,
  },
  tipDescription: {
    fontSize: 14,
    color: colors.dark.inactive,
  },
});
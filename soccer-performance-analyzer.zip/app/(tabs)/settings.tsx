import React, { useState } from 'react';
import { View, Text, StyleSheet, Switch, Pressable, Alert, ScrollView } from 'react-native';
import { Settings as SettingsIcon, Moon, Sun, Bell, Trash2, HelpCircle, Info, LogOut } from 'lucide-react-native';
import colors from '@/constants/colors';
import { useComparisonStore } from '@/store/comparison-store';

export default function SettingsScreen() {
  const { comparisons, deleteComparison } = useComparisonStore();
  
  const [darkMode, setDarkMode] = useState(true);
  const [notifications, setNotifications] = useState(true);
  const [autoPlay, setAutoPlay] = useState(false);
  
  const toggleDarkMode = () => {
    setDarkMode(!darkMode);
    // In a real app, this would update a theme store
  };
  
  const toggleNotifications = () => {
    setNotifications(!notifications);
    // In a real app, this would update notification settings
  };
  
  const toggleAutoPlay = () => {
    setAutoPlay(!autoPlay);
    // In a real app, this would update video playback settings
  };
  
  const handleClearData = () => {
    Alert.alert(
      "Clear All Data",
      "Are you sure you want to delete all your comparisons? This action cannot be undone.",
      [
        {
          text: "Cancel",
          style: "cancel"
        },
        {
          text: "Delete All",
          style: "destructive",
          onPress: () => {
            // Delete all comparisons
            comparisons.forEach(comparison => {
              deleteComparison(comparison.id);
            });
            Alert.alert("Success", "All data has been cleared.");
          }
        }
      ]
    );
  };
  
  return (
    <ScrollView style={styles.container} contentContainerStyle={styles.content}>
      <View style={styles.header}>
        <SettingsIcon size={24} color={colors.dark.text} />
        <Text style={styles.title}>Settings</Text>
      </View>
      
      <View style={styles.section}>
        <Text style={styles.sectionTitle}>Appearance</Text>
        
        <View style={styles.settingItem}>
          <View style={styles.settingInfo}>
            <View style={styles.settingIconContainer}>
              <Moon size={20} color={colors.dark.text} />
            </View>
            <Text style={styles.settingLabel}>Dark Mode</Text>
          </View>
          <Switch
            value={darkMode}
            onValueChange={toggleDarkMode}
            trackColor={{ false: colors.dark.border, true: colors.dark.primary }}
            thumbColor={colors.dark.text}
          />
        </View>
      </View>
      
      <View style={styles.section}>
        <Text style={styles.sectionTitle}>Notifications</Text>
        
        <View style={styles.settingItem}>
          <View style={styles.settingInfo}>
            <View style={styles.settingIconContainer}>
              <Bell size={20} color={colors.dark.text} />
            </View>
            <Text style={styles.settingLabel}>Enable Notifications</Text>
          </View>
          <Switch
            value={notifications}
            onValueChange={toggleNotifications}
            trackColor={{ false: colors.dark.border, true: colors.dark.primary }}
            thumbColor={colors.dark.text}
          />
        </View>
      </View>
      
      <View style={styles.section}>
        <Text style={styles.sectionTitle}>Video Playback</Text>
        
        <View style={styles.settingItem}>
          <View style={styles.settingInfo}>
            <View style={styles.settingIconContainer}>
              <Sun size={20} color={colors.dark.text} />
            </View>
            <Text style={styles.settingLabel}>Auto-Play Videos</Text>
          </View>
          <Switch
            value={autoPlay}
            onValueChange={toggleAutoPlay}
            trackColor={{ false: colors.dark.border, true: colors.dark.primary }}
            thumbColor={colors.dark.text}
          />
        </View>
      </View>
      
      <View style={styles.section}>
        <Text style={styles.sectionTitle}>Data Management</Text>
        
        <Pressable 
          style={styles.dangerButton}
          onPress={handleClearData}
        >
          <Trash2 size={20} color={colors.dark.error} />
          <Text style={styles.dangerButtonText}>Clear All Data</Text>
        </Pressable>
      </View>
      
      <View style={styles.section}>
        <Text style={styles.sectionTitle}>About</Text>
        
        <Pressable style={styles.aboutItem}>
          <HelpCircle size={20} color={colors.dark.text} />
          <Text style={styles.aboutItemText}>Help & Support</Text>
        </Pressable>
        
        <Pressable style={styles.aboutItem}>
          <Info size={20} color={colors.dark.text} />
          <Text style={styles.aboutItemText}>About Video Coach</Text>
        </Pressable>
        
        <View style={styles.versionContainer}>
          <Text style={styles.versionText}>Version 1.0.0</Text>
        </View>
      </View>
      
      <Pressable style={styles.logoutButton}>
        <LogOut size={20} color={colors.dark.text} />
        <Text style={styles.logoutButtonText}>Log Out</Text>
      </Pressable>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.dark.background,
  },
  content: {
    padding: 16,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    marginBottom: 24,
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    color: colors.dark.text,
  },
  section: {
    marginBottom: 24,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: '600',
    color: colors.dark.text,
    marginBottom: 16,
  },
  settingItem: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    backgroundColor: colors.dark.card,
    borderRadius: 12,
    padding: 16,
    marginBottom: 12,
  },
  settingInfo: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
  },
  settingIconContainer: {
    width: 36,
    height: 36,
    borderRadius: 18,
    backgroundColor: 'rgba(255,255,255,0.1)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  settingLabel: {
    fontSize: 16,
    color: colors.dark.text,
  },
  dangerButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: 'rgba(230,57,70,0.1)',
    borderRadius: 12,
    padding: 16,
    gap: 8,
  },
  dangerButtonText: {
    fontSize: 16,
    fontWeight: '600',
    color: colors.dark.error,
  },
  aboutItem: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    backgroundColor: colors.dark.card,
    borderRadius: 12,
    padding: 16,
    marginBottom: 12,
  },
  aboutItemText: {
    fontSize: 16,
    color: colors.dark.text,
  },
  versionContainer: {
    alignItems: 'center',
    marginTop: 8,
  },
  versionText: {
    fontSize: 14,
    color: colors.dark.inactive,
  },
  logoutButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: colors.dark.card,
    borderRadius: 12,
    padding: 16,
    gap: 8,
    marginTop: 8,
  },
  logoutButtonText: {
    fontSize: 16,
    fontWeight: '600',
    color: colors.dark.text,
  },
});
import React, { useState, useEffect } from 'react';
import { View, Text, StyleSheet, TextInput, ScrollView, Pressable, Alert, Platform } from 'react-native';
import { useLocalSearchParams, useRouter, Stack } from 'expo-router';
import { Image } from 'expo-image';
import { Plus, Video, X, Tag, Save, Camera } from 'lucide-react-native';
import * as ImagePicker from 'expo-image-picker';
import { useComparisonStore, VideoSourceInput } from '@/store/comparison-store';
import colors from '@/constants/colors';
import { VideoSource } from '@/types/comparison';

export default function EditComparisonScreen() {
  const { id } = useLocalSearchParams();
  const router = useRouter();
  const { getComparisonById, updateComparison } = useComparisonStore();
  const comparison = getComparisonById(id as string);
  
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [tags, setTags] = useState<string[]>([]);
  const [currentTag, setCurrentTag] = useState('');
  const [referenceVideo, setReferenceVideo] = useState<VideoSource | undefined>();
  const [trainingVideo, setTrainingVideo] = useState<VideoSource | undefined>();
  const [notes, setNotes] = useState<string[]>([]);
  const [currentNote, setCurrentNote] = useState('');
  
  useEffect(() => {
    if (!comparison) {
      router.replace('/comparisons');
      return;
    }
    
    setTitle(comparison.title);
    setDescription(comparison.description || '');
    setTags(comparison.tags || []);
    setReferenceVideo(comparison.videos.reference);
    setTrainingVideo(comparison.videos.training);
    setNotes(comparison.notes || []);
  }, [comparison]);
  
  if (!comparison) {
    return null;
  }
  
  const handleAddTag = () => {
    if (currentTag.trim() && !tags.includes(currentTag.trim())) {
      setTags([...tags, currentTag.trim()]);
      setCurrentTag('');
    }
  };
  
  const handleRemoveTag = (tagToRemove: string) => {
    setTags(tags.filter(tag => tag !== tagToRemove));
  };
  
  const handleAddNote = () => {
    if (currentNote.trim()) {
      setNotes([...notes, currentNote.trim()]);
      setCurrentNote('');
    }
  };
  
  const handleRemoveNote = (index: number) => {
    setNotes(notes.filter((_, i) => i !== index));
  };
  
  const pickVideo = async (type: 'reference' | 'training') => {
    try {
      // Request permissions first
      const permissionResult = await ImagePicker.requestMediaLibraryPermissionsAsync();
      
      if (permissionResult.granted === false) {
        Alert.alert("Permission Required", "You need to grant access to your media library to select videos.");
        return;
      }
      
      // Launch image picker
      const result = await ImagePicker.launchImageLibraryAsync({
        mediaTypes: ImagePicker.MediaTypeOptions.Videos,
        allowsEditing: true,
        quality: 1,
        videoMaxDuration: 60,
      });
      
      if (!result.canceled) {
        const asset = result.assets[0];
        
        // In a real app, we would upload the video to a server or process it locally
        // For this demo, we'll use the selected video URI and a placeholder thumbnail
        const newVideo: VideoSourceInput = {
          uri: asset.uri,
          thumbnail: type === 'reference' 
            ? "https://images.unsplash.com/photo-1535131749006-b7f58c99034b?q=80&w=2070"
            : "https://images.unsplash.com/photo-1593111774240-d529f12cf4bb?q=80&w=2069",
          title: type === 'reference' ? "Professional Reference" : "My Training Video",
          duration: 15, // Placeholder duration
        };
        
        if (type === 'reference') {
          setReferenceVideo({
            ...newVideo,
            id: Date.now().toString(),
            createdAt: Date.now()
          });
        } else {
          setTrainingVideo({
            ...newVideo,
            id: Date.now().toString(),
            createdAt: Date.now()
          });
        }
      }
    } catch (error) {
      Alert.alert("Error", "Failed to select video. Please try again.");
      console.error("Video picker error:", error);
    }
  };
  
  const recordVideo = async (type: 'reference' | 'training') => {
    try {
      // Request camera permissions
      const cameraPermission = await ImagePicker.requestCameraPermissionsAsync();
      
      if (cameraPermission.granted === false) {
        Alert.alert("Permission Required", "You need to grant access to your camera to record videos.");
        return;
      }
      
      // Launch camera
      const result = await ImagePicker.launchCameraAsync({
        mediaTypes: ImagePicker.MediaTypeOptions.Videos,
        allowsEditing: true,
        quality: 1,
        videoMaxDuration: 60,
      });
      
      if (!result.canceled) {
        const asset = result.assets[0];
        
        // In a real app, we would process the video and generate a thumbnail
        // For this demo, we'll use the recorded video URI and a placeholder thumbnail
        const newVideo: VideoSourceInput = {
          uri: asset.uri,
          thumbnail: type === 'reference' 
            ? "https://images.unsplash.com/photo-1535131749006-b7f58c99034b?q=80&w=2070"
            : "https://images.unsplash.com/photo-1593111774240-d529f12cf4bb?q=80&w=2069",
          title: type === 'reference' ? "Professional Reference" : "My Training Video",
          duration: 15, // Placeholder duration
        };
        
        if (type === 'reference') {
          setReferenceVideo({
            ...newVideo,
            id: Date.now().toString(),
            createdAt: Date.now()
          });
        } else {
          setTrainingVideo({
            ...newVideo,
            id: Date.now().toString(),
            createdAt: Date.now()
          });
        }
      }
    } catch (error) {
      Alert.alert("Error", "Failed to record video. Please try again.");
      console.error("Camera error:", error);
    }
  };
  
  const handleSave = () => {
    if (!title.trim()) {
      Alert.alert("Missing Information", "Please enter a title for your comparison.");
      return;
    }
    
    updateComparison(comparison.id, {
      title: title.trim(),
      description: description.trim() || undefined,
      videos: {
        reference: referenceVideo,
        training: trainingVideo,
      },
      tags: tags.length > 0 ? tags : undefined,
      notes: notes.length > 0 ? notes : undefined,
    });
    
    router.replace(`/comparison/${comparison.id}`);
  };
  
  return (
    <>
      <Stack.Screen options={{ title: "Edit Comparison" }} />
      
      <ScrollView style={styles.container} contentContainerStyle={styles.content}>
        {/* Basic Info */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Basic Information</Text>
          
          <View style={styles.inputContainer}>
            <Text style={styles.label}>Title</Text>
            <TextInput
              style={styles.input}
              value={title}
              onChangeText={setTitle}
              placeholder="Enter comparison title"
              placeholderTextColor={colors.dark.inactive}
            />
          </View>
          
          <View style={styles.inputContainer}>
            <Text style={styles.label}>Description (optional)</Text>
            <TextInput
              style={[styles.input, styles.textArea]}
              value={description}
              onChangeText={setDescription}
              placeholder="Describe what you're comparing"
              placeholderTextColor={colors.dark.inactive}
              multiline
              numberOfLines={4}
              textAlignVertical="top"
            />
          </View>
        </View>
        
        {/* Videos */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Videos</Text>
          
          <View style={styles.videoSection}>
            <Text style={styles.videoSectionTitle}>Reference Video (Pro/Ideal)</Text>
            
            {referenceVideo ? (
              <View style={styles.selectedVideo}>
                <Image
                  source={{ uri: referenceVideo.thumbnail }}
                  style={styles.videoThumbnail}
                  contentFit="cover"
                />
                <View style={styles.videoInfo}>
                  <Text style={styles.videoTitle}>{referenceVideo.title}</Text>
                  <Pressable 
                    style={styles.removeButton}
                    onPress={() => setReferenceVideo(undefined)}
                  >
                    <X size={16} color={colors.dark.text} />
                    <Text style={styles.removeButtonText}>Remove</Text>
                  </Pressable>
                </View>
              </View>
            ) : (
              <View style={styles.videoPickerContainer}>
                <Pressable 
                  style={styles.videoPickerButton}
                  onPress={() => pickVideo('reference')}
                >
                  <Video size={24} color={colors.dark.inactive} />
                  <Text style={styles.videoPickerText}>Select Video</Text>
                </Pressable>
                
                <Text style={styles.orText}>or</Text>
                
                <Pressable 
                  style={styles.videoPickerButton}
                  onPress={() => recordVideo('reference')}
                >
                  <Camera size={24} color={colors.dark.inactive} />
                  <Text style={styles.videoPickerText}>Record Video</Text>
                </Pressable>
              </View>
            )}
          </View>
          
          <View style={styles.videoSection}>
            <Text style={styles.videoSectionTitle}>Your Training Video</Text>
            
            {trainingVideo ? (
              <View style={styles.selectedVideo}>
                <Image
                  source={{ uri: trainingVideo.thumbnail }}
                  style={styles.videoThumbnail}
                  contentFit="cover"
                />
                <View style={styles.videoInfo}>
                  <Text style={styles.videoTitle}>{trainingVideo.title}</Text>
                  <Pressable 
                    style={styles.removeButton}
                    onPress={() => setTrainingVideo(undefined)}
                  >
                    <X size={16} color={colors.dark.text} />
                    <Text style={styles.removeButtonText}>Remove</Text>
                  </Pressable>
                </View>
              </View>
            ) : (
              <View style={styles.videoPickerContainer}>
                <Pressable 
                  style={styles.videoPickerButton}
                  onPress={() => pickVideo('training')}
                >
                  <Video size={24} color={colors.dark.inactive} />
                  <Text style={styles.videoPickerText}>Select Video</Text>
                </Pressable>
                
                <Text style={styles.orText}>or</Text>
                
                <Pressable 
                  style={styles.videoPickerButton}
                  onPress={() => recordVideo('training')}
                >
                  <Camera size={24} color={colors.dark.inactive} />
                  <Text style={styles.videoPickerText}>Record Video</Text>
                </Pressable>
              </View>
            )}
          </View>
        </View>
        
        {/* Notes */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Notes</Text>
          
          {notes.map((note, index) => (
            <View key={index} style={styles.noteItem}>
              <Text style={styles.noteText}>{note}</Text>
              <Pressable 
                style={styles.removeNoteButton}
                onPress={() => handleRemoveNote(index)}
              >
                <X size={16} color={colors.dark.text} />
              </Pressable>
            </View>
          ))}
          
          <View style={styles.noteInputContainer}>
            <TextInput
              style={[styles.input, styles.noteInput]}
              value={currentNote}
              onChangeText={setCurrentNote}
              placeholder="Add a note about your technique"
              placeholderTextColor={colors.dark.inactive}
              multiline
              numberOfLines={2}
              textAlignVertical="top"
            />
            <Pressable 
              style={styles.addNoteButton}
              onPress={handleAddNote}
              disabled={!currentNote.trim()}
            >
              <Plus size={20} color={colors.dark.text} />
            </Pressable>
          </View>
        </View>
        
        {/* Tags */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Tags (optional)</Text>
          
          <View style={styles.tagsContainer}>
            {tags.map(tag => (
              <View key={tag} style={styles.tag}>
                <Text style={styles.tagText}>{tag}</Text>
                <Pressable onPress={() => handleRemoveTag(tag)}>
                  <X size={16} color={colors.dark.text} />
                </Pressable>
              </View>
            ))}
          </View>
          
          <View style={styles.tagInputContainer}>
            <TextInput
              style={styles.tagInput}
              value={currentTag}
              onChangeText={setCurrentTag}
              placeholder="Add a tag (e.g., golf, tennis)"
              placeholderTextColor={colors.dark.inactive}
              onSubmitEditing={handleAddTag}
            />
            <Pressable 
              style={styles.addTagButton}
              onPress={handleAddTag}
              disabled={!currentTag.trim()}
            >
              <Plus size={20} color={colors.dark.text} />
            </Pressable>
          </View>
        </View>
        
        {/* Save Button */}
        <Pressable 
          style={styles.saveButton}
          onPress={handleSave}
        >
          <Save size={20} color={colors.dark.text} />
          <Text style={styles.saveButtonText}>Save Changes</Text>
        </Pressable>
      </ScrollView>
    </>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.dark.background,
  },
  content: {
    padding: 16,
    paddingBottom: 40,
  },
  section: {
    marginBottom: 24,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: '600',
    color: colors.dark.text,
    marginBottom: 16,
  },
  inputContainer: {
    marginBottom: 16,
  },
  label: {
    fontSize: 16,
    color: colors.dark.text,
    marginBottom: 8,
  },
  input: {
    backgroundColor: colors.dark.card,
    borderRadius: 8,
    padding: 12,
    fontSize: 16,
    color: colors.dark.text,
    borderWidth: 1,
    borderColor: colors.dark.border,
  },
  textArea: {
    minHeight: 100,
  },
  videoSection: {
    marginBottom: 16,
  },
  videoSectionTitle: {
    fontSize: 16,
    color: colors.dark.text,
    marginBottom: 8,
  },
  videoPickerContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    gap: 8,
  },
  videoPickerButton: {
    flex: 1,
    backgroundColor: colors.dark.card,
    borderRadius: 8,
    borderWidth: 1,
    borderColor: colors.dark.border,
    borderStyle: 'dashed',
    padding: 16,
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
  },
  videoPickerText: {
    fontSize: 14,
    color: colors.dark.inactive,
    textAlign: 'center',
  },
  orText: {
    fontSize: 14,
    color: colors.dark.inactive,
    fontWeight: '500',
  },
  selectedVideo: {
    backgroundColor: colors.dark.card,
    borderRadius: 8,
    overflow: 'hidden',
    borderWidth: 1,
    borderColor: colors.dark.border,
  },
  videoThumbnail: {
    width: '100%',
    height: 180,
  },
  videoInfo: {
    padding: 12,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  videoTitle: {
    fontSize: 16,
    color: colors.dark.text,
  },
  removeButton: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
  },
  removeButtonText: {
    fontSize: 14,
    color: colors.dark.error,
  },
  noteItem: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    backgroundColor: colors.dark.card,
    borderRadius: 8,
    padding: 12,
    marginBottom: 8,
  },
  noteText: {
    flex: 1,
    fontSize: 16,
    color: colors.dark.text,
  },
  removeNoteButton: {
    padding: 4,
  },
  noteInputContainer: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    gap: 8,
  },
  noteInput: {
    flex: 1,
    minHeight: 80,
  },
  addNoteButton: {
    width: 44,
    height: 44,
    borderRadius: 22,
    backgroundColor: colors.dark.primary,
    justifyContent: 'center',
    alignItems: 'center',
    marginTop: 8,
  },
  tagsContainer: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 8,
    marginBottom: 16,
  },
  tag: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: colors.dark.primary,
    borderRadius: 16,
    paddingVertical: 6,
    paddingHorizontal: 12,
    gap: 8,
  },
  tagText: {
    fontSize: 14,
    color: colors.dark.text,
  },
  tagInputContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
  },
  tagInput: {
    flex: 1,
    backgroundColor: colors.dark.card,
    borderRadius: 8,
    padding: 12,
    fontSize: 16,
    color: colors.dark.text,
    borderWidth: 1,
    borderColor: colors.dark.border,
  },
  addTagButton: {
    width: 44,
    height: 44,
    borderRadius: 22,
    backgroundColor: colors.dark.primary,
    justifyContent: 'center',
    alignItems: 'center',
  },
  saveButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: colors.dark.primary,
    borderRadius: 8,
    padding: 16,
    gap: 8,
  },
  saveButtonText: {
    fontSize: 16,
    fontWeight: 'bold',
    color: colors.dark.text,
  },
});
import React from 'react';
import { View, Text, StyleSheet, ScrollView, Pressable, Image } from 'react-native';
import { useRouter, Stack } from 'expo-router';
import { ArrowLeft, Layers, BarChart2, MessageSquare, Brain } from 'lucide-react-native';
import colors from '@/constants/colors';

export default function PoseAnalysisHelpScreen() {
  const router = useRouter();
  
  const handleBack = () => {
    router.back();
  };
  
  return (
    <>
      <Stack.Screen 
        options={{
          title: "Pose Analysis Guide",
          headerLeft: () => (
            <Pressable style={styles.backButton} onPress={handleBack}>
              <ArrowLeft size={20} color={colors.dark.text} />
            </Pressable>
          ),
        }}
      />
      
      <ScrollView style={styles.container} contentContainerStyle={styles.content}>
        <Text style={styles.title}>Understanding Pose Analysis</Text>
        
        <Text style={styles.description}>
          Video Coach uses advanced pose estimation technology to analyze your technique and provide detailed feedback. Here's how it works:
        </Text>
        
        <View style={styles.section}>
          <View style={styles.sectionHeader}>
            <Layers size={24} color={colors.dark.primary} />
            <Text style={styles.sectionTitle}>Skeleton Overlay</Text>
          </View>
          
          <Text style={styles.sectionText}>
            The skeleton overlay visualizes key body joints and connections, allowing you to see precise body positioning. Toggle this feature using the layers icon in video controls.
          </Text>
          
          <View style={styles.imageContainer}>
            <Image 
              source={{ uri: "https://images.unsplash.com/photo-1576610616656-d3aa5d1f4534?q=80&w=1935" }}
              style={styles.image}
              resizeMode="contain"
            />
            <View style={styles.overlayExample}>
              {/* Simplified skeleton overlay example */}
              <View style={[styles.joint, { top: 50, left: 100 }]} />
              <View style={[styles.joint, { top: 80, left: 100 }]} />
              <View style={[styles.joint, { top: 120, left: 80 }]} />
              <View style={[styles.joint, { top: 120, left: 120 }]} />
              <View style={[styles.joint, { top: 160, left: 70 }]} />
              <View style={[styles.joint, { top: 160, left: 130 }]} />
              
              <View style={[styles.bone, { top: 50, left: 100, height: 30, width: 2 }]} />
              <View style={[styles.bone, { top: 80, left: 100, width: 40, height: 2, transform: [{ rotate: '45deg' }] }]} />
              <View style={[styles.bone, { top: 80, left: 100, width: 40, height: 2, transform: [{ rotate: '-45deg' }] }]} />
              <View style={[styles.bone, { top: 120, left: 80, height: 40, width: 2 }]} />
              <View style={[styles.bone, { top: 120, left: 120, height: 40, width: 2 }]} />
            </View>
          </View>
        </View>
        
        <View style={styles.section}>
          <View style={styles.sectionHeader}>
            <BarChart2 size={24} color={colors.dark.primary} />
            <Text style={styles.sectionTitle}>Metrics Analysis</Text>
          </View>
          
          <Text style={styles.sectionText}>
            Our AI analyzes three key aspects of your technique:
          </Text>
          
          <View style={styles.metricItem}>
            <Text style={styles.metricTitle}>Angle Metrics</Text>
            <Text style={styles.metricDescription}>
              Measures joint angles (elbow, knee, hip) and compares them to the reference video. Proper angles are crucial for efficient technique.
            </Text>
          </View>
          
          <View style={styles.metricItem}>
            <Text style={styles.metricTitle}>Timing Metrics</Text>
            <Text style={styles.metricDescription}>
              Analyzes the timing of key movements in your technique compared to the reference. Proper timing is essential for coordinated movements.
            </Text>
          </View>
          
          <View style={styles.metricItem}>
            <Text style={styles.metricTitle}>Position Metrics</Text>
            <Text style={styles.metricDescription}>
              Evaluates the spatial positioning of your body parts relative to the reference. Correct positioning improves balance and power.
            </Text>
          </View>
        </View>
        
        <View style={styles.section}>
          <View style={styles.sectionHeader}>
            <MessageSquare size={24} color={colors.dark.primary} />
            <Text style={styles.sectionTitle}>AI Feedback</Text>
          </View>
          
          <Text style={styles.sectionText}>
            Based on the metrics analysis, our AI provides personalized feedback:
          </Text>
          
          <View style={styles.feedbackItem}>
            <Text style={styles.feedbackTitle}>Strengths</Text>
            <Text style={styles.feedbackDescription}>
              Highlights aspects of your technique that match the reference well.
            </Text>
          </View>
          
          <View style={styles.feedbackItem}>
            <Text style={styles.feedbackTitle}>Areas for Improvement</Text>
            <Text style={styles.feedbackDescription}>
              Identifies specific aspects that need adjustment with actionable suggestions.
            </Text>
          </View>
          
          <View style={styles.feedbackItem}>
            <Text style={styles.feedbackTitle}>Overall Score</Text>
            <Text style={styles.feedbackDescription}>
              A numerical score that represents how closely your technique matches the reference.
            </Text>
          </View>
        </View>
        
        <View style={styles.section}>
          <View style={styles.sectionHeader}>
            <Brain size={24} color={colors.dark.primary} />
            <Text style={styles.sectionTitle}>Tips for Better Analysis</Text>
          </View>
          
          <View style={styles.tipItem}>
            <View style={styles.tipNumber}>
              <Text style={styles.tipNumberText}>1</Text>
            </View>
            <View style={styles.tipContent}>
              <Text style={styles.tipTitle}>Good Lighting</Text>
              <Text style={styles.tipDescription}>
                Record in well-lit areas to ensure the AI can accurately detect your body positioning.
              </Text>
            </View>
          </View>
          
          <View style={styles.tipItem}>
            <View style={styles.tipNumber}>
              <Text style={styles.tipNumberText}>2</Text>
            </View>
            <View style={styles.tipContent}>
              <Text style={styles.tipTitle}>Clear View</Text>
              <Text style={styles.tipDescription}>
                Ensure your full body is visible in the frame without obstructions.
              </Text>
            </View>
          </View>
          
          <View style={styles.tipItem}>
            <View style={styles.tipNumber}>
              <Text style={styles.tipNumberText}>3</Text>
            </View>
            <View style={styles.tipContent}>
              <Text style={styles.tipTitle}>Similar Angles</Text>
              <Text style={styles.tipDescription}>
                Try to record from a similar angle as the reference video for the most accurate comparison.
              </Text>
            </View>
          </View>
          
          <View style={styles.tipItem}>
            <View style={styles.tipNumber}>
              <Text style={styles.tipNumberText}>4</Text>
            </View>
            <View style={styles.tipContent}>
              <Text style={styles.tipTitle}>Multiple Analyses</Text>
              <Text style={styles.tipDescription}>
                Run multiple analyses over time to track your progress and improvements.
              </Text>
            </View>
          </View>
        </View>
      </ScrollView>
    </>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.dark.background,
  },
  content: {
    padding: 16,
    paddingBottom: 40,
  },
  backButton: {
    padding: 8,
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    color: colors.dark.text,
    marginBottom: 16,
  },
  description: {
    fontSize: 16,
    color: colors.dark.text,
    lineHeight: 24,
    marginBottom: 24,
  },
  section: {
    marginBottom: 32,
    backgroundColor: colors.dark.card,
    borderRadius: 16,
    padding: 16,
  },
  sectionHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    marginBottom: 16,
  },
  sectionTitle: {
    fontSize: 20,
    fontWeight: '600',
    color: colors.dark.text,
  },
  sectionText: {
    fontSize: 16,
    color: colors.dark.text,
    lineHeight: 24,
    marginBottom: 16,
  },
  imageContainer: {
    position: 'relative',
    width: '100%',
    height: 200,
    borderRadius: 8,
    overflow: 'hidden',
    marginVertical: 16,
  },
  image: {
    width: '100%',
    height: '100%',
  },
  overlayExample: {
    ...StyleSheet.absoluteFillObject,
    backgroundColor: 'rgba(0,0,0,0.3)',
  },
  joint: {
    position: 'absolute',
    width: 10,
    height: 10,
    borderRadius: 5,
    backgroundColor: colors.dark.primary,
  },
  bone: {
    position: 'absolute',
    backgroundColor: colors.dark.primary,
    transformOrigin: 'top left',
  },
  metricItem: {
    backgroundColor: 'rgba(67, 97, 238, 0.1)',
    borderRadius: 8,
    padding: 12,
    marginBottom: 12,
  },
  metricTitle: {
    fontSize: 16,
    fontWeight: '600',
    color: colors.dark.text,
    marginBottom: 4,
  },
  metricDescription: {
    fontSize: 14,
    color: colors.dark.text,
    lineHeight: 20,
  },
  feedbackItem: {
    backgroundColor: 'rgba(67, 97, 238, 0.1)',
    borderRadius: 8,
    padding: 12,
    marginBottom: 12,
  },
  feedbackTitle: {
    fontSize: 16,
    fontWeight: '600',
    color: colors.dark.text,
    marginBottom: 4,
  },
  feedbackDescription: {
    fontSize: 14,
    color: colors.dark.text,
    lineHeight: 20,
  },
  tipItem: {
    flexDirection: 'row',
    marginBottom: 16,
    gap: 12,
  },
  tipNumber: {
    width: 28,
    height: 28,
    borderRadius: 14,
    backgroundColor: colors.dark.primary,
    justifyContent: 'center',
    alignItems: 'center',
  },
  tipNumberText: {
    fontSize: 14,
    fontWeight: 'bold',
    color: colors.dark.text,
  },
  tipContent: {
    flex: 1,
  },
  tipTitle: {
    fontSize: 16,
    fontWeight: '600',
    color: colors.dark.text,
    marginBottom: 4,
  },
  tipDescription: {
    fontSize: 14,
    color: colors.dark.text,
    lineHeight: 20,
  },
});
import React, { useState, useEffect } from 'react';
import { View, Text, StyleSheet, ScrollView, Pressable } from 'react-native';
import { useLocalSearchParams, useRouter, Stack } from 'expo-router';
import { ArrowLeft, BarChart2, MessageSquare, Info } from 'lucide-react-native';
import { useAnalysisStore } from '@/store/analysis-store';
import { useComparisonStore } from '@/store/comparison-store';
import EnhancedVideoPlayer from '@/components/EnhancedVideoPlayer';
import AnalysisMetrics from '@/components/AnalysisMetrics';
import AIFeedback from '@/components/AIFeedback';
import colors from '@/constants/colors';

export default function AnalysisDetailScreen() {
  const { id } = useLocalSearchParams();
  const router = useRouter();
  const { analyses } = useAnalysisStore();
  const { getComparisonById } = useComparisonStore();
  
  const [activeTab, setActiveTab] = useState<'metrics' | 'feedback'>('metrics');
  
  // Find the analysis by ID
  const analysis = analyses.find(a => a.id === id);
  
  // Get the associated comparison
  const comparison = analysis ? getComparisonById(analysis.comparisonId) : undefined;
  
  useEffect(() => {
    if (!analysis || !comparison) {
      router.replace('/comparisons');
    }
  }, [analysis, comparison, router]);
  
  if (!analysis || !analysis.result || !comparison) {
    return null;
  }
  
  const handleBack = () => {
    router.back();
  };
  
  return (
    <>
      <Stack.Screen 
        options={{
          title: "Analysis Results",
          headerLeft: () => (
            <Pressable style={styles.backButton} onPress={handleBack}>
              <ArrowLeft size={20} color={colors.dark.text} />
            </Pressable>
          ),
        }}
      />
      
      <View style={styles.container}>
        <View style={styles.header}>
          <Text style={styles.title}>{comparison.title}</Text>
          <View style={styles.scoreContainer}>
            <Text style={styles.scoreLabel}>Overall Score</Text>
            <View style={styles.scoreCircle}>
              <Text style={styles.scoreValue}>{analysis.result.overallScore}</Text>
            </View>
          </View>
        </View>
        
        <View style={styles.videosContainer}>
          {comparison.videos.reference && (
            <View style={styles.videoWrapper}>
              <View style={styles.videoHeader}>
                <Text style={styles.videoTitle}>Reference</Text>
                <View style={[styles.videoBadge, { backgroundColor: colors.dark.primary }]}>
                  <Text style={styles.videoBadgeText}>PRO</Text>
                </View>
              </View>
              <EnhancedVideoPlayer 
                video={comparison.videos.reference}
                poseData={analysis.referencePose?.frames[0]}
                overlayColor={colors.dark.primary}
                showPoseOverlay={true}
              />
            </View>
          )}
          
          {comparison.videos.training && (
            <View style={styles.videoWrapper}>
              <View style={styles.videoHeader}>
                <Text style={styles.videoTitle}>Your Training</Text>
                <View style={[styles.videoBadge, { backgroundColor: colors.dark.secondary }]}>
                  <Text style={styles.videoBadgeText}>YOU</Text>
                </View>
              </View>
              <EnhancedVideoPlayer 
                video={comparison.videos.training}
                poseData={analysis.userPose?.frames[0]}
                overlayColor={colors.dark.secondary}
                showPoseOverlay={true}
              />
            </View>
          )}
        </View>
        
        <View style={styles.poseInfoContainer}>
          <Info size={16} color={colors.dark.inactive} />
          <Text style={styles.poseInfoText}>
            Toggle the skeleton overlay using the layers icon in the video controls
          </Text>
        </View>
        
        {/* Tabs */}
        <View style={styles.tabsContainer}>
          <Pressable 
            style={[
              styles.tab, 
              activeTab === 'metrics' && styles.activeTab
            ]}
            onPress={() => setActiveTab('metrics')}
          >
            <BarChart2 size={18} color={activeTab === 'metrics' ? colors.dark.primary : colors.dark.inactive} />
            <Text 
              style={[
                styles.tabText,
                activeTab === 'metrics' && styles.activeTabText
              ]}
            >
              Metrics
            </Text>
          </Pressable>
          
          <Pressable 
            style={[
              styles.tab, 
              activeTab === 'feedback' && styles.activeTab
            ]}
            onPress={() => setActiveTab('feedback')}
          >
            <MessageSquare size={18} color={activeTab === 'feedback' ? colors.dark.primary : colors.dark.inactive} />
            <Text 
              style={[
                styles.tabText,
                activeTab === 'feedback' && styles.activeTabText
              ]}
            >
              AI Feedback
            </Text>
          </Pressable>
        </View>
        
        <View style={styles.tabContent}>
          {activeTab === 'metrics' ? (
            <AnalysisMetrics result={analysis.result} />
          ) : (
            <AIFeedback result={analysis.result} />
          )}
        </View>
      </View>
    </>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.dark.background,
  },
  backButton: {
    padding: 8,
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: 16,
  },
  title: {
    fontSize: 20,
    fontWeight: 'bold',
    color: colors.dark.text,
    flex: 1,
  },
  scoreContainer: {
    alignItems: 'center',
  },
  scoreLabel: {
    fontSize: 12,
    color: colors.dark.inactive,
    marginBottom: 4,
  },
  scoreCircle: {
    width: 50,
    height: 50,
    borderRadius: 25,
    backgroundColor: colors.dark.primary,
    justifyContent: 'center',
    alignItems: 'center',
  },
  scoreValue: {
    fontSize: 20,
    fontWeight: 'bold',
    color: colors.dark.text,
  },
  videosContainer: {
    flexDirection: 'row',
    padding: 16,
    paddingTop: 0,
    gap: 12,
  },
  videoWrapper: {
    flex: 1,
  },
  videoHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    marginBottom: 4,
  },
  videoTitle: {
    fontSize: 14,
    fontWeight: '600',
    color: colors.dark.text,
  },
  videoBadge: {
    paddingHorizontal: 6,
    paddingVertical: 2,
    borderRadius: 4,
  },
  videoBadgeText: {
    fontSize: 10,
    fontWeight: 'bold',
    color: colors.dark.text,
  },
  poseInfoContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    paddingHorizontal: 16,
    marginBottom: 16,
  },
  poseInfoText: {
    fontSize: 12,
    color: colors.dark.inactive,
    flex: 1,
  },
  tabsContainer: {
    flexDirection: 'row',
    borderBottomWidth: 1,
    borderBottomColor: colors.dark.border,
    marginHorizontal: 16,
  },
  tab: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 12,
    paddingHorizontal: 16,
    gap: 8,
  },
  activeTab: {
    borderBottomWidth: 2,
    borderBottomColor: colors.dark.primary,
  },
  tabText: {
    fontSize: 16,
    color: colors.dark.inactive,
  },
  activeTabText: {
    color: colors.dark.primary,
    fontWeight: '600',
  },
  tabContent: {
    flex: 1,
    padding: 16,
  },
});
import { AnalysisData, AnalysisResult, PoseSequence } from "@/types/analysis";

// Mock pose data for a golf swing
export const mockGolfSwingReferencePose: PoseSequence = {
  frames: [
    {
      joints: {
        head: { x: 0.5, y: 0.2, confidence: 0.95 },
        neck: { x: 0.5, y: 0.25, confidence: 0.95 },
        rightShoulder: { x: 0.45, y: 0.25, confidence: 0.9 },
        rightElbow: { x: 0.4, y: 0.35, confidence: 0.9 },
        rightWrist: { x: 0.35, y: 0.45, confidence: 0.85 },
        leftShoulder: { x: 0.55, y: 0.25, confidence: 0.9 },
        leftElbow: { x: 0.6, y: 0.35, confidence: 0.9 },
        leftWrist: { x: 0.65, y: 0.45, confidence: 0.85 },
        rightHip: { x: 0.45, y: 0.5, confidence: 0.9 },
        rightKnee: { x: 0.45, y: 0.7, confidence: 0.9 },
        rightAnkle: { x: 0.45, y: 0.9, confidence: 0.85 },
        leftHip: { x: 0.55, y: 0.5, confidence: 0.9 },
        leftKnee: { x: 0.55, y: 0.7, confidence: 0.9 },
        leftAnkle: { x: 0.55, y: 0.9, confidence: 0.85 },
      },
      timestamp: 0,
    },
    // More frames would be here in a real implementation
  ],
  duration: 2000, // 2 seconds
};

export const mockGolfSwingUserPose: PoseSequence = {
  frames: [
    {
      joints: {
        head: { x: 0.5, y: 0.2, confidence: 0.9 },
        neck: { x: 0.5, y: 0.25, confidence: 0.9 },
        rightShoulder: { x: 0.45, y: 0.25, confidence: 0.85 },
        rightElbow: { x: 0.38, y: 0.32, confidence: 0.85 }, // Different angle
        rightWrist: { x: 0.32, y: 0.4, confidence: 0.8 },   // Different position
        leftShoulder: { x: 0.55, y: 0.25, confidence: 0.85 },
        leftElbow: { x: 0.62, y: 0.32, confidence: 0.85 },  // Different angle
        leftWrist: { x: 0.68, y: 0.4, confidence: 0.8 },    // Different position
        rightHip: { x: 0.45, y: 0.5, confidence: 0.85 },
        rightKnee: { x: 0.45, y: 0.7, confidence: 0.85 },
        rightAnkle: { x: 0.45, y: 0.9, confidence: 0.8 },
        leftHip: { x: 0.55, y: 0.5, confidence: 0.85 },
        leftKnee: { x: 0.55, y: 0.7, confidence: 0.85 },
        leftAnkle: { x: 0.55, y: 0.9, confidence: 0.8 },
      },
      timestamp: 0,
    },
    // More frames would be here in a real implementation
  ],
  duration: 2200, // 2.2 seconds (slightly slower)
};

// Mock analysis result for golf swing
export const mockGolfSwingAnalysisResult: AnalysisResult = {
  overallScore: 78,
  angleMetrics: [
    {
      joint: "Right Elbow",
      referenceAngle: 90,
      userAngle: 85,
      difference: 5,
      isGood: true,
    },
    {
      joint: "Left Elbow",
      referenceAngle: 90,
      userAngle: 95,
      difference: 5,
      isGood: true,
    },
    {
      joint: "Torso Rotation",
      referenceAngle: 45,
      userAngle: 35,
      difference: 10,
      isGood: false,
    },
    {
      joint: "Hip Rotation",
      referenceAngle: 30,
      userAngle: 20,
      difference: 10,
      isGood: false,
    },
  ],
  timingMetrics: [
    {
      event: "Backswing",
      referenceTime: 800,
      userTime: 900,
      difference: 100,
      isGood: true,
    },
    {
      event: "Downswing",
      referenceTime: 300,
      userTime: 400,
      difference: 100,
      isGood: false,
    },
    {
      event: "Follow Through",
      referenceTime: 500,
      userTime: 600,
      difference: 100,
      isGood: true,
    },
  ],
  positionMetrics: [
    {
      joint: "Right Wrist (Impact)",
      referencePosX: 0.35,
      referencePosY: 0.45,
      userPosX: 0.32,
      userPosY: 0.4,
      distance: 0.06,
      isGood: false,
    },
    {
      joint: "Left Wrist (Impact)",
      referencePosX: 0.65,
      referencePosY: 0.45,
      userPosX: 0.68,
      userPosY: 0.4,
      distance: 0.06,
      isGood: false,
    },
    {
      joint: "Head Position",
      referencePosX: 0.5,
      referencePosY: 0.2,
      userPosX: 0.5,
      userPosY: 0.2,
      distance: 0.0,
      isGood: true,
    },
  ],
  feedback: [
    "Your swing has good elbow positioning, but needs more torso and hip rotation.",
    "Your downswing is slightly slower than the reference, which may reduce power.",
    "Wrist positioning at impact could be improved for better ball contact.",
    "Head position is excellent, showing good stability throughout the swing."
  ],
  strengths: [
    "Stable head position throughout the swing",
    "Good elbow angles during backswing",
    "Consistent timing on backswing and follow-through"
  ],
  improvements: [
    "Increase torso rotation by 10° for more power",
    "Speed up downswing by ~100ms to match reference timing",
    "Adjust wrist position at impact for better ball striking"
  ]
};

// Mock tennis serve analysis
export const mockTennisServeAnalysisResult: AnalysisResult = {
  overallScore: 82,
  angleMetrics: [
    {
      joint: "Elbow Extension",
      referenceAngle: 175,
      userAngle: 165,
      difference: 10,
      isGood: false,
    },
    {
      joint: "Knee Bend",
      referenceAngle: 120,
      userAngle: 130,
      difference: 10,
      isGood: false,
    },
    {
      joint: "Shoulder Rotation",
      referenceAngle: 90,
      userAngle: 85,
      difference: 5,
      isGood: true,
    },
  ],
  timingMetrics: [
    {
      event: "Ball Toss",
      referenceTime: 500,
      userTime: 550,
      difference: 50,
      isGood: true,
    },
    {
      event: "Racket Drop",
      referenceTime: 300,
      userTime: 350,
      difference: 50,
      isGood: true,
    },
    {
      event: "Contact Point",
      referenceTime: 200,
      userTime: 300,
      difference: 100,
      isGood: false,
    },
  ],
  positionMetrics: [
    {
      joint: "Ball Toss Height",
      referencePosX: 0.5,
      referencePosY: 0.1,
      userPosX: 0.5,
      userPosY: 0.2,
      distance: 0.1,
      isGood: false,
    },
    {
      joint: "Contact Point",
      referencePosX: 0.5,
      referencePosY: 0.15,
      userPosX: 0.55,
      userPosY: 0.25,
      distance: 0.11,
      isGood: false,
    },
  ],
  feedback: [
    "Your ball toss is lower than the reference, limiting potential power.",
    "Extend your elbow more fully at contact for better reach and power.",
    "Deepen your knee bend to generate more upward force.",
    "Your shoulder rotation and timing on the toss and racket drop are good."
  ],
  strengths: [
    "Good shoulder rotation throughout the serve",
    "Consistent timing on ball toss and racket drop",
    "Stable platform position"
  ],
  improvements: [
    "Toss the ball ~10% higher for optimal contact point",
    "Extend elbow more fully (aim for 175° vs current 165°)",
    "Deepen knee bend by ~10° for more explosive upward drive"
  ]
};

// Mock basketball shot analysis
export const mockBasketballShotAnalysisResult: AnalysisResult = {
  overallScore: 85,
  angleMetrics: [
    {
      joint: "Elbow Angle",
      referenceAngle: 90,
      userAngle: 85,
      difference: 5,
      isGood: true,
    },
    {
      joint: "Knee Bend",
      referenceAngle: 110,
      userAngle: 120,
      difference: 10,
      isGood: false,
    },
    {
      joint: "Wrist Flexion",
      referenceAngle: 70,
      userAngle: 65,
      difference: 5,
      isGood: true,
    },
  ],
  timingMetrics: [
    {
      event: "Gather",
      referenceTime: 300,
      userTime: 320,
      difference: 20,
      isGood: true,
    },
    {
      event: "Release",
      referenceTime: 200,
      userTime: 180,
      difference: 20,
      isGood: true,
    },
    {
      event: "Follow Through",
      referenceTime: 300,
      userTime: 250,
      difference: 50,
      isGood: false,
    },
  ],
  positionMetrics: [
    {
      joint: "Release Point",
      referencePosX: 0.5,
      referencePosY: 0.3,
      userPosX: 0.48,
      userPosY: 0.32,
      distance: 0.03,
      isGood: true,
    },
    {
      joint: "Foot Alignment",
      referencePosX: 0.5,
      referencePosY: 0.9,
      userPosX: 0.53,
      userPosY: 0.9,
      distance: 0.03,
      isGood: true,
    },
  ],
  feedback: [
    "Your shooting form is very good, with excellent elbow and wrist angles.",
    "Deepen your knee bend slightly for more power on longer shots.",
    "Hold your follow-through longer to maintain shot consistency.",
    "Release point and foot alignment are excellent."
  ],
  strengths: [
    "Excellent release point consistency",
    "Good elbow and wrist angles during shot",
    "Proper foot alignment and balance"
  ],
  improvements: [
    "Deepen knee bend by ~10° for more power",
    "Extend follow-through duration by ~50ms for better consistency",
    "Maintain consistent release timing across shots"
  ]
};

// Mock analysis data for different comparisons
export const mockAnalysisData: AnalysisData[] = [
  {
    id: "analysis1",
    comparisonId: "1", // Golf swing comparison
    referencePose: mockGolfSwingReferencePose,
    userPose: mockGolfSwingUserPose,
    result: mockGolfSwingAnalysisResult,
    createdAt: Date.now() - 2 * 24 * 60 * 60 * 1000,
    status: "completed",
  },
  {
    id: "analysis2",
    comparisonId: "2", // Tennis serve comparison
    result: mockTennisServeAnalysisResult,
    createdAt: Date.now() - 5 * 24 * 60 * 60 * 1000,
    status: "completed",
  },
  {
    id: "analysis3",
    comparisonId: "3", // Basketball shot comparison
    result: mockBasketballShotAnalysisResult,
    createdAt: Date.now() - 1 * 24 * 60 * 60 * 1000,
    status: "completed",
  },
];
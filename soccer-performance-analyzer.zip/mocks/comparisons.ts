import { Comparison } from "@/types/comparison";

export const mockComparisons: Comparison[] = [
  {
    id: "1",
    title: "Golf Swing Comparison",
    description: "Comparing my swing before and after training",
    createdAt: Date.now() - 7 * 24 * 60 * 60 * 1000,
    updatedAt: Date.now() - 6 * 24 * 60 * 60 * 1000,
    videos: {
      reference: {
        id: "ref1",
        uri: "https://d23dyxeqlo5psv.cloudfront.net/big_buck_bunny.mp4",
        thumbnail: "https://images.unsplash.com/photo-1535131749006-b7f58c99034b?q=80&w=2070",
        title: "Professional Swing",
        duration: 15,
        createdAt: Date.now() - 10 * 24 * 60 * 60 * 1000,
      },
      training: {
        id: "train1",
        uri: "https://d23dyxeqlo5psv.cloudfront.net/big_buck_bunny.mp4",
        thumbnail: "https://images.unsplash.com/photo-1593111774240-d529f12cf4bb?q=80&w=2069",
        title: "My Swing",
        duration: 12,
        createdAt: Date.now() - 8 * 24 * 60 * 60 * 1000,
      }
    },
    notes: ["Need to improve follow-through", "Better hip rotation"],
    tags: ["golf", "swing", "training"]
  },
  {
    id: "2",
    title: "Tennis Serve Analysis",
    description: "Working on my serve technique",
    createdAt: Date.now() - 14 * 24 * 60 * 60 * 1000,
    updatedAt: Date.now() - 14 * 24 * 60 * 60 * 1000,
    videos: {
      reference: {
        id: "ref2",
        uri: "https://d23dyxeqlo5psv.cloudfront.net/big_buck_bunny.mp4",
        thumbnail: "https://images.unsplash.com/photo-1595435934249-5df7ed86e1c0?q=80&w=1974",
        title: "Pro Serve",
        duration: 8,
        createdAt: Date.now() - 20 * 24 * 60 * 60 * 1000,
      },
      training: {
        id: "train2",
        uri: "https://d23dyxeqlo5psv.cloudfront.net/big_buck_bunny.mp4",
        thumbnail: "https://images.unsplash.com/photo-1576610616656-d3aa5d1f4534?q=80&w=1935",
        title: "My Serve",
        duration: 10,
        createdAt: Date.now() - 15 * 24 * 60 * 60 * 1000,
      }
    },
    notes: ["Toss needs to be higher", "Better knee bend"],
    tags: ["tennis", "serve", "technique"]
  },
  {
    id: "3",
    title: "Basketball Shot Form",
    description: "Improving my three-point shot",
    createdAt: Date.now() - 3 * 24 * 60 * 60 * 1000,
    updatedAt: Date.now() - 2 * 24 * 60 * 60 * 1000,
    videos: {
      reference: {
        id: "ref3",
        uri: "https://d23dyxeqlo5psv.cloudfront.net/big_buck_bunny.mp4",
        thumbnail: "https://images.unsplash.com/photo-1546519638-68e109498ffc?q=80&w=2090",
        title: "Pro Shot",
        duration: 6,
        createdAt: Date.now() - 5 * 24 * 60 * 60 * 1000,
      },
      training: {
        id: "train3",
        uri: "https://d23dyxeqlo5psv.cloudfront.net/big_buck_bunny.mp4",
        thumbnail: "https://images.unsplash.com/photo-1627627256672-027a4613d028?q=80&w=1974",
        title: "My Shot",
        duration: 7,
        createdAt: Date.now() - 4 * 24 * 60 * 60 * 1000,
      }
    },
    tags: ["basketball", "shooting", "form"]
  }
];
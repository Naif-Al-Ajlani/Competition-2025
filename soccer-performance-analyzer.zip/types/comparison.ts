export interface VideoSource {
  id: string;
  uri: string;
  thumbnail?: string;
  title: string;
  duration?: number;
  createdAt: number;
}

export interface Comparison {
  id: string;
  title: string;
  description?: string;
  createdAt: number;
  updatedAt: number;
  videos: {
    reference?: VideoSource;
    training?: VideoSource;
  };
  notes?: string[];
  tags?: string[];
}
export interface JointPosition {
  x: number;
  y: number;
  confidence: number;
}

export interface PoseData {
  joints: {
    head: JointPosition;
    neck: JointPosition;
    rightShoulder: JointPosition;
    rightElbow: JointPosition;
    rightWrist: JointPosition;
    leftShoulder: JointPosition;
    leftElbow: JointPosition;
    leftWrist: JointPosition;
    rightHip: JointPosition;
    rightKnee: JointPosition;
    rightAnkle: JointPosition;
    leftHip: JointPosition;
    leftKnee: JointPosition;
    leftAnkle: JointPosition;
  };
  timestamp: number;
}

export interface PoseSequence {
  frames: PoseData[];
  duration: number;
}

export interface AngleMetric {
  joint: string;
  referenceAngle: number;
  userAngle: number;
  difference: number;
  isGood: boolean;
}

export interface TimingMetric {
  event: string;
  referenceTime: number;
  userTime: number;
  difference: number;
  isGood: boolean;
}

export interface PositionMetric {
  joint: string;
  referencePosX: number;
  referencePosY: number;
  userPosX: number;
  userPosY: number;
  distance: number;
  isGood: boolean;
}

export interface AnalysisResult {
  overallScore: number;
  angleMetrics: AngleMetric[];
  timingMetrics: TimingMetric[];
  positionMetrics: PositionMetric[];
  feedback: string[];
  strengths: string[];
  improvements: string[];
}

export interface AnalysisData {
  id: string;
  comparisonId: string;
  referencePose?: PoseSequence;
  userPose?: PoseSequence;
  result?: AnalysisResult;
  createdAt: number;
  status: 'pending' | 'processing' | 'completed' | 'failed';
}